use std::ffi::c_void;
use std::io::{self, BufRead, Read, Write};
use std::time::Instant;

#[repr(C)]
struct Timespec {
    sec: i64,
    nsec: i64,
}
unsafe extern "C" {
    fn clock_gettime(clock: i32, out: *mut Timespec) -> i32;
}
fn cpu_time() -> f64 {
    let mut value = Timespec { sec: 0, nsec: 0 };
    assert_eq!(unsafe { clock_gettime(2, &mut value) }, 0);
    value.sec as f64 + value.nsec as f64 * 1e-9
}

macro_rules! worker {
    ($name:ident,$t:ty,$plan:ident,$execute:ident,$destroy:ident) => {
        unsafe extern "C" {
            fn $plan(h:i32,w:i32,a:*mut [$t;2],b:*mut [$t;2],sign:i32,flags:u32)->*mut c_void;
            fn $execute(p:*mut c_void);
            fn $destroy(p:*mut c_void);
        }
        fn $name(op:&str,h:usize,w:usize,stride:usize,input:&str,inverse_source:&str,output:&str)->Result<(),String> {
            if h==0 || w==0 || stride<w || h>16384 || stride>16384 { return Err("invalid shape".into()); }
            let n=h*w; let fft=op.starts_with("fft-"); let stored=h*stride;
            let buffer_bytes=(stored+if fft {10*n} else {n})*std::mem::size_of::<$t>();
            if buffer_bytes>256*1024*1024 { return Err("buffer budget exceeded".into()); }
            let load=Instant::now();
            let raw=std::fs::read(input).map_err(|e|e.to_string())?;
            if raw.len()!=stored*std::mem::size_of::<$t>() { return Err("input size mismatch".into()); }
            let x:Vec<$t>=raw.chunks_exact(std::mem::size_of::<$t>()).map(|b|<$t>::from_le_bytes(b.try_into().unwrap())).collect();
            drop(raw);
            let mut inverse_input=Vec::<[$t;2]>::new();
            if fft {
                let mut bytes=vec![0u8;2*n*std::mem::size_of::<$t>()];
                std::fs::File::open(inverse_source).and_then(|mut f|f.read_exact(&mut bytes)).map_err(|e|e.to_string())?;
                inverse_input=bytes.chunks_exact(2*std::mem::size_of::<$t>()).map(|b| {
                    let width=std::mem::size_of::<$t>();
                    [<$t>::from_le_bytes(b[..width].try_into().unwrap()),<$t>::from_le_bytes(b[width..].try_into().unwrap())]
                }).collect();
            }
            let load_s=load.elapsed().as_secs_f64(); let begin=Instant::now(); let cpu=cpu_time();
            for y in 0..h { for c in 0..w { if !x[y*stride+c].is_finite() { return Err("nonfinite input".into()); } } }
            let get=|y:isize,c:isize| -> $t { if y<0 || c<0 || y>=h as isize || c>=w as isize {0.0} else {x[y as usize*stride+c as usize]} };
            let mut out=vec![0.0 as $t;if fft {4*n} else {n}]; let kernel=Instant::now();
            if fft {
                let mut a=vec![[0.0 as $t;2];n]; let mut b=vec![[0.0 as $t;2];n];
                for y in 0..h { for c in 0..w {a[y*w+c][0]=get(y as isize,c as isize);} }
                unsafe {
                    let p=$plan(h as i32,w as i32,a.as_mut_ptr(),b.as_mut_ptr(),-1,64);
                    if p.is_null() {return Err("FFT plan failure".into());} $execute(p); $destroy(p);
                }
                for i in 0..n {for c in 0..2 {out[2*i+c]=b[i][c];}}
                b.copy_from_slice(&inverse_input);
                unsafe {
                    let p=$plan(h as i32,w as i32,b.as_mut_ptr(),a.as_mut_ptr(),1,64);
                    if p.is_null() {return Err("inverse FFT plan failure".into());} $execute(p); $destroy(p);
                }
                for i in 0..n {for c in 0..2 {out[2*n+2*i+c]=a[i][c]/n as $t;}}
            } else if op=="affine" {
                for y in 0..h {for c in 0..w {out[y*w+c]=0.75*get(y as isize,c as isize)+0.125;}}
            } else if op=="convd" || op=="convr" {
                let k=if op=="convd" {[1,4,6,4,1]} else {[1,2,4,2,1]}; let denominator=if op=="convd" {256} else {100};
                let mut weights=[0.0 as $t;25];
                for j in 0..5 {for i in 0..5 {weights[5*j+i]=(k[j]*k[i]) as $t/denominator as $t;}}
                for y in 0..h {for c in 0..w {
                    let mut sum=0.0 as $t;
                    for j in 0..5 {for i in 0..5 {sum=sum+get(y as isize+j as isize-2,c as isize+i as isize-2)*weights[5*j+i];}}
                    out[y*w+c]=sum;
                }}
            } else if op=="warp" || op=="identity" || op=="translate" {
                for y in 0..h {for c in 0..w {let y=y as isize;let c=c as isize;
                    let value=if op=="identity" {get(y,c)} else if op=="translate" {get(y+1,c+2)} else {
                        let v=(3.0/16.0)*get(y,c); let v=v+(1.0/16.0)*get(y,c+1);let v=v+(9.0/16.0)*get(y+1,c);v+(3.0/16.0)*get(y+1,c+1)
                    }; out[y as usize*w+c as usize]=value;
                }}
            } else {return Err("unknown kernel".into());}
            let kernel_s=kernel.elapsed().as_secs_f64();let total_s=begin.elapsed().as_secs_f64();let cpu_s=cpu_time()-cpu;
            let mut sink=std::fs::File::create(output).map_err(|e|e.to_string())?;
            // T is a native IEEE scalar; this target is verified little-endian Linux.
            let bytes=unsafe {std::slice::from_raw_parts(out.as_ptr() as *const u8,out.len()*std::mem::size_of::<$t>())};
            sink.write_all(bytes).map_err(|e|e.to_string())?;
            let status=std::fs::read_to_string("/proc/self/status").map_err(|e|e.to_string())?;
            let rss=status.lines().find(|l|l.starts_with("VmHWM:")).and_then(|l|l.split_whitespace().nth(1)).unwrap_or("0");
            println!("{{\"backend\":\"rust\",\"total_s\":{total_s},\"kernel_s\":{kernel_s},\"cpu_s\":{cpu_s},\"load_s\":{load_s},\"rss_kib\":{rss},\"buffer_bytes\":{buffer_bytes},\"other_backend_calls\":0}}");
            io::stdout().flush().map_err(|e|e.to_string())?; Ok(())
        }
    }
}
worker!(
    run64,
    f64,
    fftw_plan_dft_2d,
    fftw_execute,
    fftw_destroy_plan
);
worker!(
    run32,
    f32,
    fftwf_plan_dft_2d,
    fftwf_execute,
    fftwf_destroy_plan
);

fn main() {
    println!("READY");
    io::stdout().flush().unwrap();
    for line in io::stdin().lock().lines() {
        let line = line.unwrap();
        let p: Vec<&str> = line.split_whitespace().collect();
        if p.len() != 8 {
            eprintln!("invalid command");
            std::process::exit(2);
        }
        let dims = (
            p[2].parse::<usize>(),
            p[3].parse::<usize>(),
            p[4].parse::<usize>(),
        );
        let result = match dims {
            (Ok(h), Ok(w), Ok(s)) => match p[0] {
                "f32" => run32(p[1], h, w, s, p[5], p[6], p[7]),
                "f64" => run64(p[1], h, w, s, p[5], p[6], p[7]),
                _ => Err("unknown precision".into()),
            },
            _ => Err("invalid dimensions".into()),
        };
        if let Err(error) = result {
            eprintln!("{error}");
            std::process::exit(2);
        }
    }
}
