#include <fftw3.h>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <sys/resource.h>
#include <vector>

static double cpu_time() {
    timespec t{};
    if (clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &t)) throw std::runtime_error("clock failure");
    return double(t.tv_sec) + double(t.tv_nsec) * 1e-9;
}

template<class T> struct Fourier;
template<> struct Fourier<double> {
    static void run(int h, int w, double* a, double* b, int sign) {
        auto p = fftw_plan_dft_2d(h, w, reinterpret_cast<fftw_complex*>(a), reinterpret_cast<fftw_complex*>(b), sign, FFTW_ESTIMATE);
        if (!p) throw std::runtime_error("FFT plan failure");
        fftw_execute(p); fftw_destroy_plan(p);
    }
};
template<> struct Fourier<float> {
    static void run(int h, int w, float* a, float* b, int sign) {
        auto p = fftwf_plan_dft_2d(h, w, reinterpret_cast<fftwf_complex*>(a), reinterpret_cast<fftwf_complex*>(b), sign, FFTW_ESTIMATE);
        if (!p) throw std::runtime_error("FFT plan failure");
        fftwf_execute(p); fftwf_destroy_plan(p);
    }
};

template<class T> void run(const std::string& op, int h, int w, int stride, const std::string& input, const std::string& inverse_source, const std::string& output) {
    if (!std::numeric_limits<T>::is_iec559 || h <= 0 || w <= 0 || stride < w || h > 16384 || stride > 16384)
        throw std::runtime_error("invalid shape or IEEE format");
    const size_t n = size_t(h) * size_t(w), stored = size_t(h) * size_t(stride);
    const bool fft = op.starts_with("fft-");
    const size_t buffer_bytes = (stored + (fft ? 10 : 1) * n) * sizeof(T);
    if (buffer_bytes > 256 * 1024 * 1024) throw std::runtime_error("buffer budget exceeded");
    auto load_begin = std::chrono::steady_clock::now();
    std::vector<T> x(stored);
    std::ifstream source(input, std::ios::binary | std::ios::ate);
    if (!source || source.tellg() != std::streamoff(stored * sizeof(T))) throw std::runtime_error("input size mismatch");
    source.seekg(0); source.read(reinterpret_cast<char*>(x.data()), std::streamsize(stored * sizeof(T)));
    if (!source) throw std::runtime_error("input read failure");
    std::vector<T> inverse_input(fft ? 2*n : 0);
    if (fft) {
        std::ifstream inverse_file(inverse_source, std::ios::binary);
        inverse_file.read(reinterpret_cast<char*>(inverse_input.data()),std::streamsize(2*n*sizeof(T)));
        if (!inverse_file) throw std::runtime_error("inverse input read failure");
    }
    double load_s = std::chrono::duration<double>(std::chrono::steady_clock::now() - load_begin).count();
    auto begin = std::chrono::steady_clock::now(); double cpu_begin = cpu_time();
    for (int y = 0; y < h; ++y) for (int c = 0; c < w; ++c)
        if (!std::isfinite(x[size_t(y) * stride + c])) throw std::runtime_error("nonfinite input");
    std::vector<T> out((fft ? 4 : 1) * n);
    auto kernel_begin = std::chrono::steady_clock::now();
    auto get = [&](int y, int c) -> T { return y < 0 || c < 0 || y >= h || c >= w ? T(0) : x[size_t(y) * stride + c]; };
    if (fft) {
        std::vector<T> a(2*n, T(0)), b(2*n, T(0));
        for (int y=0; y<h; ++y) for (int c=0; c<w; ++c) a[2*(size_t(y)*w+c)] = get(y,c);
        Fourier<T>::run(h,w,a.data(),b.data(),FFTW_FORWARD);
        for (size_t i=0; i<2*n; ++i) { out[i]=b[i]; b[i]=inverse_input[i]; }
        Fourier<T>::run(h,w,b.data(),a.data(),FFTW_BACKWARD);
        for (size_t i=0; i<2*n; ++i) out[2*n+i]=a[i]/T(n);
    } else if (op == "affine") {
        for (int y=0; y<h; ++y) for (int c=0; c<w; ++c) out[size_t(y)*w+c] = T(0.75)*get(y,c)+T(0.125);
    } else if (op == "convd" || op == "convr") {
        const int dyadic[5]={1,4,6,4,1}, rational[5]={1,2,4,2,1};
        const int* k = op == "convd" ? dyadic : rational;
        const int denominator = op == "convd" ? 256 : 100;
        T weights[25];
        for (int y=0; y<5; ++y) for (int c=0; c<5; ++c) weights[5*y+c] = T(k[y]*k[c])/T(denominator);
        for (int y=0; y<h; ++y) for (int c=0; c<w; ++c) {
            T sum=0;
            for (int j=0; j<5; ++j) for (int i=0; i<5; ++i) sum = sum + get(y+j-2,c+i-2)*weights[5*j+i];
            out[size_t(y)*w+c]=sum;
        }
    } else if (op == "warp" || op == "identity" || op == "translate") {
        for (int y=0; y<h; ++y) for (int c=0; c<w; ++c) {
            T value;
            if (op=="identity") value=get(y,c);
            else if (op=="translate") value=get(y+1,c+2);
            else { value=T(3.0/16)*get(y,c); value=value+T(1.0/16)*get(y,c+1); value=value+T(9.0/16)*get(y+1,c); value=value+T(3.0/16)*get(y+1,c+1); }
            out[size_t(y)*w+c]=value;
        }
    } else throw std::runtime_error("unknown kernel");
    double kernel_s=std::chrono::duration<double>(std::chrono::steady_clock::now()-kernel_begin).count();
    double total_s=std::chrono::duration<double>(std::chrono::steady_clock::now()-begin).count(), cpu_s=cpu_time()-cpu_begin;
    std::ofstream sink(output,std::ios::binary|std::ios::trunc);
    sink.write(reinterpret_cast<const char*>(out.data()),std::streamsize(out.size()*sizeof(T))); sink.close();
    if (!sink) throw std::runtime_error("output write failure");
    rusage usage{}; getrusage(RUSAGE_SELF,&usage);
    std::cout << std::setprecision(17) << "{\"backend\":\"cpp\",\"total_s\":" << total_s << ",\"kernel_s\":" << kernel_s << ",\"cpu_s\":" << cpu_s << ",\"load_s\":" << load_s << ",\"rss_kib\":" << usage.ru_maxrss << ",\"buffer_bytes\":" << buffer_bytes << ",\"other_backend_calls\":0}" << std::endl;
}

int main() {
    std::cout << "READY" << std::endl;
    std::string dtype, op, input, inverse_source, output; int h,w,stride;
    try {
        while (std::cin >> dtype >> op >> h >> w >> stride >> input >> inverse_source >> output) {
            if (dtype=="f32") run<float>(op,h,w,stride,input,inverse_source,output);
            else if (dtype=="f64") run<double>(op,h,w,stride,input,inverse_source,output);
            else throw std::runtime_error("unknown precision");
        }
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 2; }
}
