import argparse
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import random
import selectors
import statistics
import subprocess
import sys
import time

import numpy as np

ROOT = Path('/opt/workspace/astroProcessor')
BASE = ROOT / 'tmp/m1/a'
BACKENDS = {
    'cpp': [str(ROOT / 'tmp/m1/build/core-cpp')],
    'rust': [str(ROOT / 'tmp/m1/build/core-rust')],
    'numpy': ['/usr/bin/python3', '-B', str(ROOT / 'tmp/m1/src/numpy_worker.py')],
}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


class Child:
    def __init__(self, backend, directory, suffix=''):
        self.backend = backend
        self.stderr_path = directory / f'{backend}{suffix}.stderr'
        self.stderr = self.stderr_path.open('w')
        self.start = time.perf_counter()
        self.process = subprocess.Popen(BACKENDS[backend], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=self.stderr, text=True, bufsize=1)
        self.peak_kib = 0
        self.selector = selectors.DefaultSelector()
        self.selector.register(self.process.stdout, selectors.EVENT_READ)
        if self.readline() != 'READY':
            raise RuntimeError(f'{backend}: missing READY')
        self.startup_s = time.perf_counter() - self.start

    def readline(self):
        start = time.monotonic()
        while True:
            status = Path(f'/proc/{self.process.pid}/status')
            if status.exists():
                for line in status.read_text().splitlines():
                    if line.startswith('VmRSS:'):
                        self.peak_kib = max(self.peak_kib, int(line.split()[1]))
            if self.peak_kib > 512 * 1024 or time.monotonic() - start > 180:
                self.process.kill()
                self.process.wait()
                raise RuntimeError(f'{self.backend}: own child exceeded RSS/time safety guard')
            if self.selector.select(0.02):
                line = self.process.stdout.readline()
                if not line:
                    raise RuntimeError(f'{self.backend}: child exited {self.process.wait()}; see {self.stderr_path.name}')
                return line.rstrip('\n')

    def invoke(self, case, output):
        fields = [case['dtype'], case['op'], case['h'], case['w'], case['stride'], case['input'], case.get('inverse_source', '-'), str(output)]
        begin = time.perf_counter()
        self.process.stdin.write(' '.join(map(str, fields)) + '\n')
        self.process.stdin.flush()
        result = json.loads(self.readline())
        result['request_wall_s'] = time.perf_counter() - begin
        result['supervisor_peak_rss_kib'] = self.peak_kib
        result['output_sha256'] = digest(output)
        result['case'] = case['id']
        return result

    def close(self):
        if self.process.poll() is None:
            self.process.stdin.close()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
        self.selector.close()
        self.stderr.close()


def shift(values, dy, dx):
    h, w = values.shape
    result = np.zeros_like(values)
    y0, y1 = max(0, -dy), min(h, h - dy)
    x0, x1 = max(0, -dx), min(w, w - dx)
    result[y0:y1, x0:x1] = values[y0+dy:y1+dy, x0+dx:x1+dx]
    return result


def integer_oracle(q, op):
    if op == 'affine':
        return 3 * q + 512, 4096
    if op in ('convd', 'convr'):
        k, d = ([1, 4, 6, 4, 1], 256) if op == 'convd' else ([1, 2, 4, 2, 1], 100)
        result = np.zeros_like(q)
        for j in range(5):
            for i in range(5):
                result += shift(q, j - 2, i - 2) * (k[j] * k[i])
        return result, 1024 * d
    if op == 'warp':
        return 3*q + shift(q, 0, 1) + 9*shift(q, 1, 0) + 3*shift(q, 1, 1), 16384
    if op == 'translate':
        return shift(q, 1, 2), 1024
    return q.copy(), 1024


def fraction_check(q, op, numerator, denominator):
    h, w = q.shape
    def get(y, x):
        return Fraction(int(q[y, x]), 1024) if 0 <= y < h and 0 <= x < w else Fraction(0)
    for y in range(h):
        for x in range(w):
            if op in ('convd', 'convr'):
                k, d = ([1, 4, 6, 4, 1], 256) if op == 'convd' else ([1, 2, 4, 2, 1], 100)
                value = sum((get(y+j-2, x+i-2) * Fraction(k[j]*k[i], d)
                             for j in range(5) for i in range(5)), Fraction(0))
            elif op == 'affine':
                value = Fraction(3, 4)*get(y, x) + Fraction(1, 8)
            elif op == 'warp':
                value = sum((get(y+dy, x+dx)*Fraction(v, 16)
                             for dy, dx, v in ((0, 0, 3), (0, 1, 1), (1, 0, 9), (1, 1, 3))), Fraction(0))
            elif op == 'translate':
                value = get(y+1, x+2)
            else:
                value = get(y, x)
            assert value == Fraction(int(numerator[y, x]), denominator), (op, y, x)


def rational_bound(dtype):
    scalar = np.float32 if dtype == 'f32' else np.float64
    p = 24 if dtype == 'f32' else 53
    u = Fraction(1, 2**p)
    gamma = 50*u / (1-50*u)
    coefficients = []
    representation = Fraction(0)
    magnitude = Fraction(0)
    for j in (1, 2, 4, 2, 1):
        for i in (1, 2, 4, 2, 1):
            rounded = scalar(j*i) / scalar(100)
            actual, exact = Fraction(float(rounded)), Fraction(j*i, 100)
            magnitude += abs(actual)
            representation += abs(actual-exact)
            coefficients.append(float(rounded).hex())
    # |x| <= 1/2 bounds every pointwise sum, including zero-padded borders.
    bound = (gamma*magnitude + representation) / 2
    floor = float(bound)
    if Fraction(floor) > bound:
        floor = float(np.nextafter(floor, -np.inf))
    ceil = float(bound)
    if Fraction(ceil) < bound:
        ceil = float(np.nextafter(ceil, np.inf))
    return {'exact': str(bound), 'floor_f64': floor, 'ceil_f64': ceil,
            'gamma50': str(gamma), 'coefficient_hex': coefficients,
            'derivation': 'pointwise B bounded above using max abs x <= 1/2; no observed residual used'}


def generate(directory):
    fixtures = directory / 'fixtures'
    fixtures.mkdir()
    bounds = {dtype: rational_bound(dtype) for dtype in ('f32', 'f64')}
    write_json(directory / 'bounds-before-results.json', bounds)
    cases = []
    checked = set()
    for precision in ('f32', 'f64'):
        scalar = np.float32 if precision == 'f32' else np.float64
        for h, w in ((17, 19), (257, 263), (1024, 1024)):
            q = ((73*np.arange(h*w, dtype=np.int64)+19) % 1024 - 512).reshape(h, w)
            for padding in (0, 17):
                stride = w+padding
                data = np.full((h, stride), 123, dtype=scalar)
                data[:, :w] = q / 1024
                source = fixtures / f'input-{precision}-{h}-{w}-{stride}.bin'
                data.tofile(source)
                for op in ('affine', 'convd', 'convr', 'warp', 'identity', 'translate'):
                    name = f'{op}-{precision}-{h}-{w}-s{stride}'
                    numerator, denominator = integer_oracle(q, op)
                    if h == 17 and op not in checked:
                        fraction_check(q, op, numerator, denominator)
                        checked.add(op)
                    truth = fixtures / f'{name}.gt-int64.bin'
                    numerator.tofile(truth)
                    cases.append(dict(id=name, dtype=precision, op=op, h=h, w=w, stride=stride,
                                      input=str(source), input_sha256=digest(source), gt=str(truth),
                                      gt_sha256=digest(truth), denominator=denominator,
                                      tolerance=bounds[precision] if op=='convr' else 'exact zero'))
        for h in (32, 1024):
            for padding in (0, 17):
                stride = h+padding
                for pattern in ('impulse', 'constant', 'mode'):
                    name=f'fft-{pattern}-{precision}-{h}-{h}-s{stride}'
                    x=np.zeros((h, stride), dtype=scalar)
                    if pattern=='impulse':
                        x[0, 0]=1
                    elif pattern=='constant':
                        x[:, :h]=1
                    else:
                        x[:, :h]=np.tile(np.array([1, 0, -1, 0], dtype=scalar), h//4)
                    x[:, h:]=123
                    source=fixtures/f'{name}.input.bin'; x.tofile(source)
                    truth=np.zeros(4*h*h, dtype=scalar)
                    spectral=truth[:2*h*h].reshape(h, h, 2)
                    if pattern=='impulse': spectral[:, :, 0]=1
                    elif pattern=='constant': spectral[0, 0, 0]=h*h
                    else:
                        spectral[0, h//4, 0]=h*h//2
                        spectral[0, 3*h//4, 0]=h*h//2
                    truth[2*h*h:].reshape(h, h, 2)[:, :, 0]=x[:, :h]
                    gt=fixtures/f'{name}.gt.bin'; truth.tofile(gt)
                    cases.append(dict(id=name,dtype=precision,op='fft-'+pattern,h=h,w=h,stride=stride,
                                      input=str(source),input_sha256=digest(source),gt=str(gt),gt_sha256=digest(gt),
                                      denominator=None,tolerance='exact zero for the preregistered spectral fixtures'))
    write_json(directory/'cases.json', cases)
    write_json(directory/'oracle.json', dict(scalar_fraction_shapes='17x19',scalar_fraction_operations=sorted(checked),
                                             generation='integer index and exact Fraction; FFT analytical closed form',
                                             finite_inputs=True,non_dyadic_bound_precedes_results=True))
    return cases


def compare(case, path):
    scalar=np.float32 if case['dtype']=='f32' else np.float64
    actual=np.fromfile(path,dtype=scalar)
    if case['denominator'] is None:
        expected=np.fromfile(case['gt'],dtype=scalar)
        ok=actual.shape==expected.shape and np.array_equal(actual,expected)
        error=float(np.max(np.abs(actual.astype(np.float64)-expected))) if actual.shape==expected.shape else None
    else:
        numerator=np.fromfile(case['gt'],dtype=np.int64)
        if actual.size!=numerator.size or not np.isfinite(actual).all():
            return dict(pass_=False,error='size or nonfinite output')
        reference=numerator.astype(np.float64)/case['denominator']
        error=float(np.max(np.abs(actual.astype(np.float64)-reference)))
        if case['op']!='convr':
            ok=np.array_equal(actual,reference.astype(scalar))
        else:
            low=np.nextafter(reference,-np.inf); high=np.nextafter(reference,np.inf)
            upper=np.nextafter(np.maximum(np.abs(actual.astype(np.float64)-low),np.abs(actual.astype(np.float64)-high)),np.inf)
            ambiguous=np.flatnonzero(upper>case['tolerance']['floor_f64'])
            bound=Fraction(case['tolerance']['exact'])
            ok=all(abs(Fraction(float(actual[i]))-Fraction(int(numerator[i]),case['denominator']))<=bound for i in ambiguous)
    return dict(pass_=bool(ok),max_abs_error_diagnostic=error,output_sha256=digest(path))


def scratch_guard(additional):
    allocated=sum(p.stat().st_blocks*512 for p in (ROOT/'tmp').rglob('*') if p.is_file() and not p.is_symlink())
    if allocated+additional>1024**3:
        raise RuntimeError('scratch safety budget would be exceeded; no fixture reduction')


def generate_current(directory):
    # Reuse immutable old fixture bytes, not old validation verdicts or timings.
    old=json.loads((BASE/'series-001/cases.json').read_text())
    cases=[]
    fixtures=directory/'fixtures';fixtures.mkdir()
    bounds={dtype:rational_bound(dtype) for dtype in ('f32','f64')}
    write_json(directory/'bounds-before-results.json',bounds)
    for item in old:
        case=dict(item)
        assert digest(case['input'])==case['input_sha256']
        assert digest(case['gt'])==case['gt_sha256']
        if case['op'].startswith('fft-'):
            case['inverse_source']=case['gt']
            case['inverse_source_prefix_scalars']=2*case['h']*case['w']
            if case['op']=='fft-mode':
                case['id']=case['id'].replace('fft-mode-','fft-cosx-')
                case['op']='fft-cosx'
        elif case['op']=='convr':
            case['tolerance']=bounds[case['dtype']]
        cases.append(case)
    for precision in ('f32','f64'):
        scalar=np.float32 if precision=='f32' else np.float64
        for h in (32,1024):
            for pattern,axis,sine in (('cosy',0,False),('sinx',1,True),('siny',0,True)):
                vector=np.tile(np.array([0,1,0,-1] if sine else [1,0,-1,0],dtype=scalar),h//4)
                real=np.broadcast_to(vector[None,:] if axis==1 else vector[:,None],(h,h))
                truth=np.zeros(4*h*h,dtype=scalar)
                spectral=truth[:2*h*h].reshape(h,h,2)
                k0=(0,h//4) if axis==1 else (h//4,0)
                k1=(0,3*h//4) if axis==1 else (3*h//4,0)
                spectral[k0[0],k0[1],1 if sine else 0]=-(h*h//2) if sine else h*h//2
                spectral[k1[0],k1[1],1 if sine else 0]=h*h//2
                truth[2*h*h:].reshape(h,h,2)[:,:,0]=real
                gt=fixtures/f'fft-{pattern}-{precision}-{h}.gt.bin'
                scratch_guard(truth.nbytes);truth.tofile(gt)
                for padding in (0,17):
                    stride=h+padding
                    data=np.full((h,stride),123,dtype=scalar);data[:,:h]=real
                    source=fixtures/f'fft-{pattern}-{precision}-{h}-s{stride}.input.bin'
                    scratch_guard(data.nbytes);data.tofile(source)
                    name=f'fft-{pattern}-{precision}-{h}-{h}-s{stride}'
                    cases.append(dict(id=name,dtype=precision,op='fft-'+pattern,h=h,w=h,stride=stride,
                                      input=str(source),input_sha256=digest(source),gt=str(gt),gt_sha256=digest(gt),
                                      inverse_source=str(gt),inverse_source_prefix_scalars=2*h*h,
                                      denominator=None,tolerance='exact zero; real and imaginary components; independent inverse input'))
    write_json(directory/'cases.json',cases)
    write_json(directory/'oracle.json',dict(reused_immutable_fixtures='series-001',reused_results=False,
        fft_patterns=['impulse','constant','cosx','cosy','sinx','siny'],forward_sign=-1,inverse_sign=1,
        inverse_input='first 2*N scalars of independently generated analytical spectrum; never candidate forward output',
        inverse_expected='independent known spatial pattern; both real and imaginary components checked',
        scalar_fraction_crosscheck='series-001/oracle.json, unchanged integer/rational fixture bytes verified by hash',
        non_dyadic_bound_precedes_results=True))
    return cases


def manifest(directory):
    files=list((ROOT/'tmp/m1/src').glob('*'))+[ROOT/'tmp/m1/env.sh',ROOT/'plans/M1-spikes.md',
                                             ROOT/'tmp/m1/build/core-cpp',ROOT/'tmp/m1/build/core-rust']
    write_json(directory/'source-manifest-before-results.json',
               {str(p.relative_to(ROOT)):digest(p) for p in files if p.is_file()})
    write_json(directory/'versions.json',dict(python=sys.version.split()[0],numpy=np.__version__,
                                             byteorder=sys.byteorder,precision={str(t):str(np.finfo(t)) for t in (np.float32,np.float64)},
                                             threads={k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')}))


def validate(directory):
    directory.mkdir(exist_ok=False)
    manifest(directory)
    cases=generate_current(directory)
    work=directory/'work';work.mkdir()
    workers={}
    results=[]
    try:
        for backend in BACKENDS: workers[backend]=Child(backend,work)
        with (directory/'validation.jsonl').open('w',buffering=1) as log:
            for case in cases:
                for backend,worker in workers.items():
                    output=work/f'{backend}.bin'
                    result=worker.invoke(case,output)
                    quality=compare(case,output)
                    row=dict(backend=backend,case=case['id'],quality=quality,metrics=result)
                    log.write(json.dumps(row,allow_nan=False)+'\n');results.append(row)
                    if not quality['pass_']:
                        output.rename(work/f"FAIL-{case['id']}-{backend}.bin")
                        write_json(directory/'validation-summary.json',dict(status='FAIL',completed=len(results),failed=row))
                        raise RuntimeError(f"numeric failure: {backend} {case['id']}")
                print('PASS',case['id'],flush=True)
        write_json(directory/'validation-summary.json',dict(status='PASS',cases=len(cases),candidate_results=len(results),
                                                            ffi_ownership='NOT RUN',mask_fault='NOT RUN',sanitizers='NOT RUN'))
    finally:
        for worker in workers.values(): worker.close()


def summary(directory, samples):
    grouped={}
    for row in samples:
        grouped.setdefault((row['case'],row['backend']),[]).append(row)
    values=[];ratios=[]
    rng=random.Random(4059)
    for (case,backend),rows in grouped.items():
        times=[row['total_s'] for row in rows]
        median=statistics.median(times)
        values.append(dict(case=case,backend=backend,n=len(times),median_s=median,
                           mad_s=statistics.median(abs(v-median) for v in times),min_s=min(times),max_s=max(times)))
    for case in sorted({c for c,b in grouped}):
        for first,second in (('cpp','rust'),('cpp','numpy'),('rust','numpy')):
            a={(v['p'],v['r']):v['total_s'] for v in grouped[(case,first)]}
            b={(v['p'],v['r']):v['total_s'] for v in grouped[(case,second)]}
            assert len(a)==len(b)==21
            observed=math.exp(statistics.median(math.log(a[key]/b[key]) for key in sorted(a)))
            boot=[]
            for _ in range(2000):
                logs=[]
                for _cluster in range(3):
                    p=rng.randrange(1,4)
                    for _round in range(7):
                        r=rng.randrange(1,8)
                        logs.append(math.log(a[(p,r)]/b[(p,r)]))
                boot.append(math.exp(statistics.median(logs)))
            boot.sort()
            ratios.append(dict(case=case,numerator=first,denominator=second,ratio=observed,
                               percentile95=np.percentile(boot,[2.5,97.5],method='linear').tolist(),seed=4059,resamples=2000,
                               clusters=3,rounds_per_cluster=7,statistic='exp(median(log(Tref/Tcandidate)))',
                               limit='three process clusters; same host/session only'))
    write_json(directory/'timing-summary.json',values)
    write_json(directory/'paired-bootstrap.json',ratios)


def measure(directory):
    assert json.loads((directory/'validation-summary.json').read_text())['status']=='PASS'
    before=json.loads((directory/'source-manifest-before-results.json').read_text())
    for name,expected in before.items(): assert digest(ROOT/name)==expected,('changed source',name)
    cases=json.loads((directory/'cases.json').read_text())
    work=directory/'work'
    assert not (directory/'samples.jsonl').exists()
    samples=[]
    with (directory/'samples.jsonl').open('w',buffering=1) as log, (directory/'cold-process.jsonl').open('w',buffering=1) as coldlog:
        for case in cases:
            for p in range(1,4):
                workers={}
                try:
                    for backend in BACKENDS:
                        workers[backend]=Child(backend,work,f'-p{p}')
                        coldlog.write(json.dumps(dict(case=case['id'],backend=backend,p=p,startup_s=workers[backend].startup_s,
                                                      phase='process-startup-not-page-cache-cold'))+'\n')
                    for repeat in range(9):
                        for backend,worker in workers.items():
                            row=worker.invoke(case,work/f'{backend}.bin')
                            assert compare(case,work/f'{backend}.bin')['pass_']
                            row.update(phase='warmup' if repeat<2 else 'warm',p=p,r=repeat-1)
                            log.write(json.dumps(row)+'\n')
                            if repeat>=2: samples.append(row)
                finally:
                    for worker in workers.values(): worker.close()
            print('MEASURED',case['id'],flush=True)
    summary(directory,samples)
    write_json(directory/'measure-summary.json',dict(status='PASS',cases=len(cases),warm_samples=len(samples),
                                                    startup_samples=3*3*len(cases),warmups=2*3*3*len(cases),
                                                    missing=['FFI ownership','mask validation','special-value copy tests','fault injection','C++ sanitizer run']))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--unit',choices=['a'],required=True)
    parser.add_argument('--phase',choices=['validate','measure'],required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert sys.byteorder=='little'
    (validate if args.phase=='validate' else measure)(args.output.resolve())
