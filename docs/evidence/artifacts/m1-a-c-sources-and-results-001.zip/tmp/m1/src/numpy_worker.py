import json
import resource
import sys
import time
import numpy as np


def run(fields):
    precision, op, hs, ws, ss, source, inverse_source, destination = fields
    dtype = {'f32': np.float32, 'f64': np.float64}[precision]
    h, w, stride = int(hs), int(ws), int(ss)
    if h <= 0 or w <= 0 or stride < w or h > 16384 or stride > 16384:
        raise ValueError('invalid shape')
    fft = op.startswith('fft-')
    buffer_bytes = (h * stride + (10 if fft else 4) * h * w) * np.dtype(dtype).itemsize
    if buffer_bytes > 256 * 1024 * 1024:
        raise ValueError('buffer budget exceeded')
    load = time.perf_counter()
    raw = np.fromfile(source, dtype=dtype)
    if raw.size != h * stride:
        raise ValueError('input size mismatch')
    x = raw.reshape(h, stride)[:, :w]
    inverse_input = None
    if fft:
        inverse_input = np.fromfile(inverse_source,dtype=dtype,count=2*h*w)
        if inverse_input.size != 2*h*w:
            raise ValueError('inverse input size mismatch')
    load_s = time.perf_counter() - load
    begin, cpu = time.perf_counter(), time.process_time()
    if not np.isfinite(x).all():
        raise ValueError('nonfinite input')
    kernel = time.perf_counter()
    if fft:
        z = np.fft.fft2(x)
        complex_dtype = np.complex64 if dtype == np.float32 else np.complex128
        inverse = np.fft.ifft2(inverse_input.view(complex_dtype).reshape(h,w))
        if z.dtype != complex_dtype or inverse.dtype != complex_dtype:
            raise ValueError('FFT precision changed')
        out = np.concatenate((z.ravel().view(dtype), inverse.ravel().view(dtype)))
    elif op == 'affine':
        out = np.empty((h, w), dtype=dtype)
        np.multiply(x, dtype(0.75), out=out)
        np.add(out, dtype(0.125), out=out)
    elif op in ('convd', 'convr'):
        k = [1, 4, 6, 4, 1] if op == 'convd' else [1, 2, 4, 2, 1]
        denominator = 256 if op == 'convd' else 100
        padded = np.pad(x, 2, mode='constant')
        out = np.zeros((h, w), dtype=dtype)
        temp = np.empty_like(out)
        for j in range(5):
            for i in range(5):
                weight = dtype(k[j] * k[i]) / dtype(denominator)
                np.multiply(padded[j:j+h, i:i+w], weight, out=temp)
                np.add(out, temp, out=out)
    elif op in ('warp', 'identity', 'translate'):
        if op == 'identity':
            out = x.copy()
        else:
            padded = np.pad(x, ((0, 1), (0, 2)), mode='constant')
            if op == 'translate':
                out = padded[1:h+1, 2:w+2].copy()
            else:
                out = np.zeros((h, w), dtype=dtype)
                temp = np.empty_like(out)
                for dy, dx, numerator in ((0, 0, 3), (0, 1, 1), (1, 0, 9), (1, 1, 3)):
                    np.multiply(padded[dy:dy+h, dx:dx+w], dtype(numerator / 16), out=temp)
                    np.add(out, temp, out=out)
    else:
        raise ValueError('unknown kernel')
    kernel_s = time.perf_counter() - kernel
    total_s, cpu_s = time.perf_counter() - begin, time.process_time() - cpu
    out.tofile(destination)
    return dict(backend='numpy', total_s=total_s, kernel_s=kernel_s, cpu_s=cpu_s,
                load_s=load_s, rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                buffer_bytes=buffer_bytes, other_backend_calls=0)


print('READY', flush=True)
for line in sys.stdin:
    try:
        print(json.dumps(run(line.split())), flush=True)
    except Exception as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(2)
