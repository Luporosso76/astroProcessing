import hashlib
import json
from pathlib import Path
import sys

ROOT=Path('/opt/workspace/astroProcessor')
sys.path.insert(0,str(ROOT/'tmp/m1/src'))
import run


def main():
    series=ROOT/'tmp/m1/a/series-002'
    cases=json.loads((series/'cases.json').read_text())
    expected={c['id'] for c in cases}
    samples=[json.loads(line) for line in (series/'samples.jsonl').read_text().splitlines()]
    cold=[json.loads(line) for line in (series/'cold-process.jsonl').read_text().splitlines()]
    grouped={}
    for row in samples:
        key=(row['case'],row['backend'],row['p'])
        grouped.setdefault(key,[]).append(row)
        assert row['total_s']>0 and row['buffer_bytes']<=256*1024**2
        assert max(row['rss_kib'],row['supervisor_peak_rss_kib'])<=512*1024
    assert len(grouped)==len(cases)*3*3
    for rows in grouped.values():
        assert [r['r'] for r in rows if r['phase']=='warmup']==[-1,0]
        assert [r['r'] for r in rows if r['phase']=='warm']==list(range(1,8))
    assert len(cold)==len(cases)*3*3
    assert {r['case'] for r in cold}==expected
    for case in expected:
        for backend in run.BACKENDS:
            rows=[r for r in cold if r['case']==case and r['backend']==backend]
            assert sorted(r['p'] for r in rows)==[1,2,3]
    for name,expected_hash in json.loads((series/'source-manifest-before-results.json').read_text()).items():
        assert run.digest(ROOT/name)==expected_hash,('changed input/source',name)
    # Check the implemented hierarchical bootstrap against an exact constant-ratio GT.
    stats=series/'statistics-selftest';stats.mkdir(exist_ok=False)
    synthetic=[]
    for p in range(1,4):
        for r in range(1,8):
            base=float(p*10+r)
            for backend,factor in (('cpp',2),('rust',1),('numpy',4)):
                synthetic.append(dict(case='known-ratios',backend=backend,p=p,r=r,total_s=base*factor))
    run.summary(stats,synthetic)
    exact={('cpp','rust'):2.0,('cpp','numpy'):0.5,('rust','numpy'):0.25}
    for row in json.loads((stats/'paired-bootstrap.json').read_text()):
        value=exact[(row['numerator'],row['denominator'])]
        assert row['ratio']==value and row['percentile95']==[value,value]
    result=dict(status='PASS',cases=len(cases),warm_samples=sum(r['phase']=='warm' for r in samples),
                warmups=sum(r['phase']=='warmup' for r in samples),startup_samples=len(cold),
                source_hashes_unchanged=True,statistics_constant_ratio_selftest=True,
                peak_reported_rss_kib=max(max(r['rss_kib'],r['supervisor_peak_rss_kib']) for r in samples),
                scratch_allocated_bytes=sum(p.stat().st_blocks*512 for p in (ROOT/'tmp').rglob('*') if p.is_file() and not p.is_symlink()))
    assert result['scratch_allocated_bytes']<=1024**3
    run.write_json(series/'measurement-audit.json',result)
    print(json.dumps(result))


if __name__=='__main__':
    main()
