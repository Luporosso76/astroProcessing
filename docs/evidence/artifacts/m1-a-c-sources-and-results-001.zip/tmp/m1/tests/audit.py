import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT=Path('/opt/workspace/astroProcessor')
sys.path.insert(0,str(ROOT/'tmp/m1/src'))
import run


def pointwise_data(case):
    scalar=np.float32 if case['dtype']=='f32' else np.float64
    raw=np.fromfile(case['input'],dtype=scalar).reshape(case['h'],case['stride'])[:,:case['w']]
    q=(raw.astype(np.float64)*1024).astype(np.int64)
    assert np.array_equal(q/1024,raw)
    sums=np.zeros_like(q)
    k=(1,2,4,2,1)
    base=Fraction(float(scalar(1)/scalar(100)))
    for j in range(5):
        for i in range(5):
            assert Fraction(float(scalar(k[j]*k[i])/scalar(100)))==base*k[j]*k[i]
            sums+=run.shift(np.abs(q),j-2,i-2)*k[j]*k[i]
    precision=24 if case['dtype']=='f32' else 53
    u=Fraction(1,2**precision)
    factor=(50*u/(1-50*u)*abs(base)+abs(base-Fraction(1,100)))/1024
    return sums,factor


def pointwise_compare(case,output):
    scalar=np.float32 if case['dtype']=='f32' else np.float64
    actual=np.fromfile(output,dtype=scalar)
    numerator=np.fromfile(case['gt'],dtype=np.int64)
    sums,factor=pointwise_data(case)
    s=sums.ravel()
    lower_factor=float(factor)
    if Fraction(lower_factor)>factor: lower_factor=float(np.nextafter(lower_factor,-np.inf))
    bound_lower=np.nextafter(s.astype(np.float64)*lower_factor,-np.inf)
    bound_lower[s==0]=0
    ref=numerator.astype(np.float64)/case['denominator']
    lo=np.nextafter(ref,-np.inf);hi=np.nextafter(ref,np.inf)
    upper_error=np.nextafter(np.maximum(np.abs(actual.astype(np.float64)-lo),np.abs(actual.astype(np.float64)-hi)),np.inf)
    ambiguous=np.flatnonzero(upper_error>bound_lower)
    failures=[]
    for i in ambiguous:
        exact_error=abs(Fraction(float(actual[i]))-Fraction(int(numerator[i]),case['denominator']))
        if exact_error>int(s[i])*factor: failures.append(int(i))
    return dict(pass_=not failures,exact_fallback_pixels=int(ambiguous.size),failed_pixels=failures[:10],
                max_abs_error_diagnostic=float(np.max(np.abs(actual.astype(np.float64)-ref))),
                pointwise_factor=str(factor),sums_sha256=hashlib.sha256(sums.tobytes()).hexdigest())


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=('pointwise','faults','asan'),required=True)
    args=parser.parse_args()
    series=ROOT/'tmp/m1/a/series-002'
    out=series/('audit-'+args.phase);out.mkdir(exist_ok=False)
    cases=json.loads((series/'cases.json').read_text())
    run.write_json(out/'source-manifest.json',{str(p.relative_to(ROOT)):run.digest(p) for p in
        (Path(__file__),ROOT/'tmp/m1/src/run.py',ROOT/'tmp/m1/build/core-cpp',ROOT/'tmp/m1/build/core-rust',ROOT/'plans/M1-spikes.md')})
    if args.phase=='pointwise':
        selected=[c for c in cases if c['op']=='convr']
        # Freeze all local bounds from inputs before reading any candidate output.
        bounds=[]
        for case in selected:
            sums,factor=pointwise_data(case)
            bounds.append(dict(case=case['id'],factor=str(factor),sums_sha256=hashlib.sha256(sums.tobytes()).hexdigest(),
                               formula='B[pixel]=(gamma50*abs(c0)+abs(c0-1/100))*sum(kj*ki*abs(q_neighbor))/1024'))
        run.write_json(out/'pointwise-bounds-before-results.json',bounds)
        measured={}
        with (series/'samples.jsonl').open() as stream:
            for line in stream:
                row=json.loads(line)
                if row['phase']=='warm': measured.setdefault((row['case'],row['backend']),set()).add(row['output_sha256'])
        results=[]
        for backend in run.BACKENDS:
            worker=run.Child(backend,out)
            try:
                for case in selected:
                    output=series/'work'/f'{backend}.bin'
                    metrics=worker.invoke(case,output)
                    quality=pointwise_compare(case,output)
                    quality['same_as_all_measured_outputs']=measured[(case['id'],backend)]=={metrics['output_sha256']}
                    row=dict(case=case['id'],backend=backend,quality=quality)
                    results.append(row)
                    run.write_json(out/'results.json',results)
                    assert quality['pass_'] and quality['same_as_all_measured_outputs'],row
            finally: worker.close()
        run.write_json(out/'summary.json',dict(status='PASS',candidate_results=len(results),bounds='actual pointwise preregistered B, not global maximum'))
    elif args.phase=='asan':
        run.BACKENDS['cpp-asan']=[str(ROOT/'tmp/m1/build/core-cpp-asan')]
        worker=run.Child('cpp-asan',out)
        results=[]
        try:
            for case in cases:
                output=series/'work/cpp.bin'
                worker.invoke(case,output)
                quality=pointwise_compare(case,output) if case['op']=='convr' else run.compare(case,output)
                results.append(dict(case=case['id'],quality=quality))
                run.write_json(out/'results.json',results)
                assert quality['pass_'],case['id']
        finally: worker.close()
        stderr=(out/'cpp-asan.stderr').read_text()
        assert not stderr,stderr
        run.write_json(out/'summary.json',dict(status='PASS',cases=len(results),binary_sha256=run.digest(ROOT/'tmp/m1/build/core-cpp-asan'),
                                              limit='only our C++ code instrumented; prebuilt FFTW not recompiled'))
    else:
        results=[]
        for precision in ('f32','f64'):
            scalar=np.float32 if precision=='f32' else np.float64
            nan=out/f'nan-{precision}.bin';np.array([np.nan],dtype=scalar).tofile(nan)
            finite=out/f'finite-{precision}.bin';np.array([0],dtype=scalar).tofile(finite)
            base=dict(dtype=precision,op='affine',h=1,w=1,stride=1,input=str(finite))
            fault_cases=[('nan',dict(base,input=str(nan))),('shape',dict(base,w=2)),
                         ('budget',dict(base,h=16384,w=16384,stride=16384)),
                         ('size',dict(base,h=2,w=2,stride=2)),('operation',dict(base,op='unsupported')),
                         ('precision',dict(base,dtype='f16'))]
            for name,case in fault_cases:
                for backend in run.BACKENDS:
                    worker=run.Child(backend,out,f'-{precision}-{name}')
                    destination=out/f'{backend}-{precision}-{name}.output'
                    try:
                        fields=[case['dtype'],case['op'],case['h'],case['w'],case['stride'],case['input'],'-',str(destination)]
                        worker.process.stdin.write(' '.join(map(str,fields))+'\n');worker.process.stdin.flush()
                        try:
                            unexpected=worker.readline()
                        except RuntimeError:
                            unexpected=None
                        code=worker.process.wait(timeout=5)
                    finally: worker.close()
                    diagnostic=worker.stderr_path.read_text().strip()
                    row=dict(case=name,dtype=precision,backend=backend,exit_code=code,diagnostic=diagnostic,output_published=destination.exists(),
                             unexpected_response=unexpected,dispatch_counts={b:int(b==backend) for b in run.BACKENDS})
                    results.append(row);run.write_json(out/'results.json',results)
                    assert code==2 and diagnostic and unexpected is None and not destination.exists(),row
            special=out/f'special-{precision}.bin'
            tiny=np.finfo(scalar).smallest_subnormal;normal=np.finfo(scalar).tiny
            np.array([0.0,-0.0,tiny,-tiny,normal,-normal],dtype=scalar).tofile(special)
            case=dict(dtype=precision,op='identity',h=1,w=6,stride=6,input=str(special))
            for backend in run.BACKENDS:
                worker=run.Child(backend,out,f'-{precision}-special')
                try:
                    destination=out/f'special-copy-{precision}-{backend}.bin'
                    worker.invoke(dict(case,id='special-copy'),destination)
                    ok=special.read_bytes()==destination.read_bytes()
                    results.append(dict(case='special-bitwise-copy',dtype=precision,backend=backend,pass_=ok))
                    assert ok
                finally: worker.close()
        run.write_json(out/'results.json',results)
        run.write_json(out/'summary.json',dict(status='PASS',fault_stop_cases=36,special_copy_cases=6,
                                              missing=['mask mismatch','FFI ownership release/double-release','internal library no-fallback proof']))
    print(args.phase,'PASS')


if __name__=='__main__':
    main()
