import json
from pathlib import Path
import sys

ROOT=Path('/opt/workspace/astroProcessor')
sys.path.insert(0,str(ROOT/'tmp/m1/src'))
import run

series=ROOT/'tmp/m1/a/series-002'
out=series/'backend-identity';out.mkdir(exist_ok=False)
case=json.loads((series/'cases.json').read_text())[0]
results=[]
for backend in run.BACKENDS:
    child=run.Child(backend,out)
    try:
        output=series/'work'/f'{backend}.bin'
        metrics=child.invoke(case,output)
        assert run.compare(case,output)['pass_']
        status=Path(f'/proc/{child.process.pid}/status').read_text()
        threads=int(next(line for line in status.splitlines() if line.startswith('Threads:')).split()[1])
        results.append(dict(requested=backend,reported=metrics['backend'],threads_after_affine=threads,
                            other_backend_calls=metrics['other_backend_calls'],
                            limit='post-kernel snapshot, not a trace of transient threads during all timed kernels'))
    finally:
        child.close()
    assert child.process.returncode==0
run.write_json(out/'results.json',results)
print(json.dumps(results))
