export ROOT=/opt/workspace/astroProcessor
export TMPDIR="$ROOT/tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
export XDG_CACHE_HOME="$ROOT/tmp/cache" XDG_CONFIG_HOME="$ROOT/tmp/config"
export CARGO_HOME="$ROOT/tmp/cargo" CARGO_TARGET_DIR="$ROOT/tmp/m1/build/rust"
export MESA_SHADER_CACHE_DIR="$ROOT/tmp/cache/mesa" MESA_SHADER_CACHE_DISABLE=true
export __GL_SHADER_DISK_CACHE=0 __GL_SHADER_DISK_CACHE_PATH="$ROOT/tmp/cache/nvidia"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export OPENSSL_CONF=/dev/null
export RUST_TOOLCHAIN_DIR="${RUST_TOOLCHAIN_DIR:-$HOME/.rustup/toolchains/1.99.0-x86_64-unknown-linux-gnu}"
mkdir -p "$ROOT/tmp/m1/src" "$ROOT/tmp/m1/build" "$ROOT/tmp/m1/e" "$ROOT/tmp/m1/a" "$XDG_CACHE_HOME" "$XDG_CONFIG_HOME"
