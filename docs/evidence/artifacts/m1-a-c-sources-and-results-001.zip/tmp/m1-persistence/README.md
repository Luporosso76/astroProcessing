# M1.c: sorgenti isolati per persistenza e crash

Stato della consegna: **IMPLEMENTATO, NON ESEGUITO**. Non costituisce M1.c PASS.
Questi sorgenti usa e getta non fanno parte del prodotto. Non modificano piani,
stato, documentazione canonica o Git. Non richiedono rete o installazioni.

Modello dichiarato dal runtime dell'autore: `openai/gpt-6.1-sol`.
Fonti lette interamente prima della scrittura:

- `AGENTS.md`: 52 righe.
- `plans/M1-spikes.md`: 169 righe.
- `docs/decisions/M0-policy.md`: 26 righe.
- `PLANS.md`: 46 righe.
- `ISTRUZIONI_OPERATIVE.md`: 164 righe.
- Sorgenti ricevuti: `persist.py` 402 righe, `run.py` 791 righe,
  questo `README.md` 165 righe. Sono stati letti integralmente prima delle patch.

SHA-256 del protocollo letto:
`1f04fa01a6042ce66c1c1e511de798a92bd6c0b8b7be17ece0ffda0abb20cbba`.
Indice CodeGraph assente; nessun indice creato. Nessuna lettura dei sorgenti o
dei report attivi di `tmp/m1/{a,e,f,d}` durante questa correzione.

Il percorso distinto `tmp/m1-persistence/` segue l'incarico del coordinatore e
non usa `tmp/m1/`. Nessuna review indipendente è ancora attestata qui.

## Esecuzione futura, solo dopo il via del coordinatore

Non avviare questi comandi mentre un altro candidato è in misura.
Eseguire dalla radice del progetto. `--output` deve indicare una directory nuova
direttamente sotto questa cartella. Una serie esistente non viene sovrascritta.

```bash
export ROOT=/opt/workspace/astroProcessor
export TMPDIR="$ROOT/tmp" PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
export XDG_CACHE_HOME="$ROOT/tmp/cache" XDG_CONFIG_HOME="$ROOT/tmp/config"
export OPENSSL_CONF=/dev/null
/usr/bin/python3 -I -B tmp/m1-persistence/run.py --unit c --phase validate --backend both --series-id m1c-v2-01 --output tmp/m1-persistence/paired-series-v2-01
```

`both` seleziona SQLite e JSON come candidati primari prima del preflight.
Non è una catena di recupero. Un errore interrompe la serie; non causa un retry
con l'altro backend. Sono disponibili anche `--backend sqlite` e `--backend json`
per serie singole, che non producono un confronto appaiato.
Il supervisore usa un ambiente minimo per i propri figli, con TMP/cache/config
dentro la serie. Non legge HOME, profili, credenziali o dati personali.

La misura richiede prima la validazione riuscita dello stesso backend e lo
stesso hash della ricetta. Non avvia la validazione automaticamente.

```bash
/usr/bin/python3 -I -B tmp/m1-persistence/run.py --unit c --phase measure --backend both --series-id m1c-v2-01 --output tmp/m1-persistence/paired-series-v2-01
```

Una seconda misura nella stessa serie viene rifiutata. Misura e validazione
devono coincidere per ID esplicito, candidati, hash della ricetta, hash del
protocollo e hash dei sorgenti. Le serie del protocollo v1 non sono accettate
né rietichettate come confermative. Una correzione richiede una nuova serie,
conservando quella precedente. Il piano deve corrispondere all'hash fissato
nel sorgente prima di qualunque esecuzione.

## Protocollo congelato nel sorgente

`run.py:PROTOCOL` registra la ricetta prima dei casi. Il manifest include hash
SHA-256 dei sorgenti, di questo testo, del piano e della policy M0. Registra
anche versione Python/SQLite, comando, filesystem tramite device/fsid/statvfs,
formula, oracle e limiti. Il report non legge i metadati personali del sistema.

Il supervisore crea directory nuove, private (`0700`), senza seguire symlink.
Ogni figlio riceve un fd della propria directory e un manifest su pipe ereditata,
legato a inode/device, PID del supervisore, azione, backend e ID della serie.
Un worker invocato direttamente con il solo `--case`, oppure con manifest non
coincidente, termina prima di usare il caso. Non accetta directory preesistenti
come nuovi casi. Gli fd ancorano le operazioni a directory verificate con
`openat`/`O_NOFOLLOW`; i file regolari devono avere esattamente un link.
Mutazioni e copie aprono prima il file senza `O_TRUNC`, verificano tipo/nlink,
poi scrivono o troncano. Il chmod usa `fchmod` su un fd di directory verificato.
SQLite riceve solo file controllati in directory private; i suoi accessi interni
non sono intercettati da Python. Questi vincoli evitano alias nelle fixture e
invocazioni accidentali del worker: **non costituiscono una sandbox OS** contro
un processo ostile con lo stesso UID o privilegi superiori.

SYN-STATE contiene 256 record con payload ASCII di **1024 byte ciascuno**, più
ID intero, ricetta e parent hash. La dimensione serializzata del record è quindi
leggermente superiore a 1 KiB. Formula del carattere alla posizione `j`:
`chr(33 + (73*j + 19*id + 11*generation) % 94)`.
La generazione 1 ha parent hash nullo; la 2 ha il digest logico della 1.
Il supervisore costruisce gli hash attesi con un secondo generatore, prima dei
casi. I checksum delle generazioni devono essere distinti. Non usa l'output
del candidato come verità. L'originale sintetico è persistente, modo `0444`, e
viene verificato dopo i casi senza mai modificarlo.

Entrambi i formati contengono i record e riferiscono un blob esterno con stato
`COMMITTED`. Il blob contiene gli stessi record e il checksum logico. Il writer
scrive e sincronizza il blob, lo rinomina e sincronizza la sua directory prima
di pubblicare il nuovo progetto. JSON usa un temporaneo nello stesso store,
fsync file, rename atomico e fsync directory. SQLite usa una transazione WAL
con `synchronous=FULL`; registra i valori effettivi. Il lock applicativo è
`flock` non bloccante: writer esclusivo, reader condiviso, conflitto esplicito.
Il writer rifiuta una generazione attesa non più corrente.

Il reader SQLite copia main e WAL sotto lock in scratch privato e apre la copia
`mode=ro`. Questo evita creazione o mutazione di sidecar nello store, anche per
schema futuro. Il costo di copia e `integrity_check` appartiene al tempo di
riapertura di questo prototipo; non rappresenta un reader di prodotto ottimizzato.
Lo schema futuro restituisce soltanto `READ_ONLY`, non un risultato `COMPLETED`.
Una prova confronta hash e nomi di tutti i file/sidecar prima e dopo lettura e
tentativo di scrittura rifiutato.

Il recovery valida integralmente il commit corrente prima di segnalare orfani.
Non pubblica, ripara o cancella gli orfani. Uno stato corrente non COMPLETED,
un blob non COMMITTED, assente o con hash errato produce STOP, exit non nullo e
nessun nuovo output. La presenza del blob valido di generazione 1 non autorizza
a recuperarlo dopo un guasto del commit corrente di generazione 2.

## Crash e prove implementate, tutte NON ESEGUITE alla consegna

Ogni punto usa un processo figlio nuovo, tre repliche per backend. Il writer
emette il punto e resta fermo su una pipe. Il supervisore può inviare SIGKILL
soltanto mediante l'oggetto `Popen` del proprio figlio. Non usa gruppi, PID
forniti dall'esterno, `pkill` o processi estranei.

1. `after_write`: transazione SQL preparata o JSON `.next` scritto; blob scritto.
2. `after_file_sync`: fsync del blob; JSON sincronizza anche il manifest `.next`.
3. `before_commit`: blob rinominato e directory sincronizzata, prima di COMMIT/rename.
4. `after_commit`: COMMIT FULL ritornato, oppure rename JSON ritornato prima del fsync directory.
5. `before_ack`: durabilità richiesta completata, ACK non ancora emesso.
6. `after_ack`: supervisore ha ricevuto ACK, figlio fermo al punto successivo.

L'hook 2 riguarda il **file esterno**, non un fsync interno del journal SQLite.
La standard library non espone un hook nel fsync interno del WAL. Il prototipo
non attribuisce a SQLite fsync directory eseguiti dall'applicazione. Gli eventi
riportano separatamente fsync applicativi e I/O SQLite non strumentato.
Il test SIGKILL non prova power-loss, cache del dispositivo o fsync che mentono.
Queste prove restano `NOT_RUN`, non PASS.

Il trace registra soltanto operazioni completate, con numero d'ordine, ruolo e
destinazione. Prima di ACK il writer e il supervisore verificano la sequenza:
fsync blob, fsync manifest `.next` (solo JSON), rename blob, fsync directory blob,
COMMIT FULL ritornato (SQLite) oppure rename manifest e fsync directory progetto
(JSON). Il trace aggiunge ACK solo dopo il ritorno dell'emissione sulla pipe.
`COMMIT FULL ritornato` non è un fsync osservato: i fsync SQLite restano
`NOT_INSTRUMENTED`. Le regressioni omettono le chiamate effettive di fsync blob
e directory blob; JSON omette inoltre fsync manifest e directory progetto.
Ogni omissione deve causare `DURABILITY_ORDER`, uscita non nulla e nessun ACK.
Non occorre simulare power-loss per controllare questo ordine applicativo.

Ai punti 1-5 il reader deve restituire l'intera generazione 1 oppure l'intera 2.
Dopo ACK deve restituire esattamente la 2. Il confronto logico ha tolleranza zero.
L'harness conserva file e log di ogni caso, anche dopo un errore.

Altri casi implementati:

- Baseline 1, commit 2, recovery distinto e corretto.
- Due writer sovrapposti: uno attende al punto 3, l'altro riceve CONFLICT.
  Anche reader durante writer e writer con generazione obsoleta ricevono CONFLICT.
- Scritture positive corte completate tramite loop; ritorno zero dopo il primo
  frammento rifiutato; ENOSPC simulato dopo almeno 4096 byte senza riempire disco.
- Prenotazione insufficiente simulata nel writer, prima delle nuove scritture.
- Scratch senza bit di scrittura e scratch che è un file anziché directory.
  Il primo caso verifica anche la policy applicativa quando il runtime privilegiato
  potrebbe ignorare i bit Unix. Non pretende di dimostrare un EACCES del kernel.
  Preflight e prenotazione precedono anche snapshot/copia SQLite. I test richiedono
  le categorie esatte `SCRATCH_UNWRITABLE`, `SCRATCH_NOT_DIRECTORY` o `RESERVATION`,
  zero accessi backend/snapshot/writer, store/sidecar invariati e nessuna nuova
  voce scratch. Un generico `PermissionError`/`NotADirectoryError` non basta.
- Progetto troncato, stato progetto PREPARED, blob alterato/non COMMITTED/assente,
  record modificato, chiavi JSON duplicate, NaN e UTF-8 invalido. Anche SQLite
  deve rifiutare documenti metadata corrotti. Il vecchio blob resta disponibile,
  ma non viene mai scelto come ripiego.
- Schema futuro 999 letto senza modificare store o sidecar, writer rifiutato.
- Migrazione sintetica esplicita 0 -> 1 riuscita e guasto prima di commit/rename.
  Dopo il guasto restano schema 0 e contenuto originale esatto, soltanto read-only.
- Manifest capability non valido, scratch symlink, manifest symlink e hardlink.
  Un sentinel sintetico nello stesso caso deve conservare contenuto e modo;
  nessun percorso esterno viene usato per simulare corruzione o permessi.

Restano tutti i **38 casi originali per backend**, senza rimozioni o skip.
Le regressioni aggiunte portano il totale pianificato a 44 casi SQLite e 46 JSON.
Nessuno di questi numeri rappresenta test eseguiti.

## Risorse, report e limiti

Buffer pianificati entro 16 MiB, sotto il limite preregistrato di 256 MiB.
Preflight richiede 192 MiB liberi e spazio pianificato entro 1 GiB nell'intero
`tmp/` del workspace, comprese le altre serie conservate. Il supervisore verifica
byte allocati (`st_blocks`) e RSS dei
propri figli, con SIGKILL oltre 512 MiB osservati o guardia di 60 secondi.
Sono controlli best effort, non garanzie anti-OOM. Ogni figlio limita address
space a 768 MiB, file individuale a 32 MiB e disabilita core dump. Un limite
fallito non riduce dataset, repliche, precisione o backend.

`manifest.json`, `cases.json`, `cases.jsonl` e `recovery.json` distinguono casi
implementati da casi eseguiti. Un caso non raggiunto resta NOT_RUN. Gli errori
attesi contano come riusciti solo se il figlio restituisce STOP/CONFLICT non
nullo, senza ACK o nuovo output; il recovery separato deve preservare il commit
precedente nei guasti di scrittura. Le chiamate ai due adapter vengono contate
separatamente. L'adapter non selezionato deve restare a zero.
`artifacts.json` registra gli hash SHA-256 dei report effettivamente scritti.

La fase measure crea tre repliche di processo distinte `p=1,2,3` per candidato.
Ogni processo resta vivo per due warm-up e sette round `r=1,...,7`:
21 campioni misurati per candidato. Dentro ciascuna replica il supervisore alterna
l'ordine SQLite/JSON a ogni round; il candidato inattivo aspetta sulla pipe.
Startup fino a readiness e totale esterno del processo sono registrati a parte.
Processo nuovo non significa page cache fredda. Non vengono eseguiti altri
benchmark contemporaneamente.

Ogni campione conserva `p,r`, backend, PID, unità e metodo. Registra caricamento
fixture fuori dal tempo misurato, `T_total_ns` da prima del preflight writer alla
riapertura verificata, CPU, primitive COMMIT/rename, durabilità fino all'ACK e
riapertura. Conta byte applicativi scritti, snapshot copiato, letture esplicite
di manifest/blob/originale, allocazione fisica del caso e delta `/proc/self/io`.
Il costo della verifica logica fa parte di questo prototipo. Heap Python e I/O
interno SQLite non sono strumentati come allocazioni o fsync applicativi:
restano dichiarati tali. RSS di processo, picco osservato dal supervisore e
thread sono diagnostici distinti dai budget pianificati. I tempi validate
includono handshake e non sono campioni di benchmark.

`measure/samples.json` riporta campioni, schedule, mediana, MAD, minimo e massimo.
Con `both` confronta le coppie dello stesso caso/p/r, con riferimento SQLite e
candidato JSON fissati prima dell'esecuzione:
`exp(median(log(T_sqlite[p,r]/T_json[p,r])))`. Il bootstrap appaiato gerarchico usa
2000 ricampionamenti, seed 4059: tre cluster di processo con reinserimento,
poi sette coppie di round con reinserimento entro ciascun cluster estratto.
Riutilizza gli stessi indici per i candidati e calcola percentili 2,5/97,5 con
interpolazione lineare. Applica la stessa statistica a totale, commit e riapertura.
Tre cluster descrivono soltanto questa serie. Nessuna soglia di latenza diventa requisito.
Nessuna scelta SQLite/JSON, validazione di prodotto, power-loss o compatibilità
Linux L1/L2/L3 deriva da questa preparazione dei sorgenti.

## Verifica della preparazione

Durante questa consegna sono consentiti soltanto parsing AST dei due sorgenti e
`bash -n` dei blocchi shell qui sopra, oltre a letture/hash dei file stabili.
Entrambi i sorgenti hanno superato il parsing AST; i due blocchi shell hanno
superato `bash -n`. Questi controlli verificano la sintassi, non la semantica.
Nessun import di `persist.py`/`run.py`, nessun test, processo worker o benchmark.
I quattro finding hanno correzioni e regressioni nel codice; la loro verifica
dinamica e la review indipendente della consegna restano da svolgere.
