"""Spike M1.c isolato: nessuna API di prodotto e nessun fallback."""

import contextlib
import errno
import fcntl
import functools
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import time
import uuid


SCHEMA = 1
COUNT = 256
PAYLOAD_BYTES = 1024
POINTS = (
    "after_write", "after_file_sync", "before_commit", "after_commit",
    "before_ack", "after_ack",
)
ORIGINAL = b"SYN-STATE immutable synthetic original\n" * 32
BACKEND_CALLS = {"sqlite": 0, "json": 0}
TRUSTED_FDS = set()
ACCESS_EVENTS = []


@contextlib.contextmanager
def directory(path):
    """Percorre directory con openat/NOFOLLOW; accetta solo capability fd registrate."""
    parts = Path(path).absolute().parts
    if parts[1:4] == ("proc", "self", "fd"):
        anchor = int(parts[4])
        require(anchor in TRUSTED_FDS, "unregistered directory capability")
        fd = os.dup(anchor)
        tail = parts[5:]
    else:
        fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        tail = parts[1:]
    try:
        for name in tail:
            require(name not in (".", ".."), "unsafe directory component")
            next_fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = next_fd
        yield fd
    finally:
        os.close(fd)


def open_regular(path, flags, mode=0o600):
    with directory(path.parent) as parent:
        fd = os.open(path.name, flags | os.O_NOFOLLOW | os.O_NONBLOCK, mode, dir_fd=parent)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise Stop("UNSAFE_FILE", "regular file with exactly one link required: " + path.name)
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_bytes(path):
    with os.fdopen(open_regular(path, os.O_RDONLY), "rb") as stream:
        return stream.read()


def mkdir(path):
    with directory(path.parent) as parent:
        os.mkdir(path.name, mode=0o700, dir_fd=parent)


def unlink(path, is_dir=False):
    with directory(path.parent) as parent:
        (os.rmdir if is_dir else os.unlink)(path.name, dir_fd=parent)


def replace(source, target):
    with directory(source.parent) as src, directory(target.parent) as dst:
        # Non si sostituiscono alias preesistenti, neppure hardlink.
        try:
            fd = open_regular(target, os.O_RDONLY)
        except FileNotFoundError:
            pass
        else:
            os.close(fd)
        os.replace(source.name, target.name, src_dir_fd=src, dst_dir_fd=dst)


def chmod_directory(path, mode):
    with directory(path) as fd:
        os.fchmod(fd, mode)


def inspect_sqlite_files(store):
    for name in ("project.sqlite", "project.sqlite-wal", "project.sqlite-shm", "project.sqlite-journal"):
        try:
            fd = open_regular(store / name, os.O_RDONLY)
        except FileNotFoundError:
            continue
        os.close(fd)


class Stop(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def require(condition, message):
    if not condition:
        raise Stop("INVALID_STATE", message)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode("utf-8")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with os.fdopen(open_regular(path, os.O_RDONLY), "rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def strict_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise Stop("DUPLICATE_KEY", key)
            result[key] = value
        return result

    def constant(value):
        raise Stop("NONFINITE_JSON", value)

    return json.loads(data.decode("utf-8", errors="strict"),
                      object_pairs_hook=pairs, parse_constant=constant)


def records(generation):
    parent = "0" * 64 if generation == 1 else logical_hash(1)
    return [{"id": i, "recipe": "SYN-STATE/g%d" % generation,
             "parent_hash": parent,
             "payload": "".join(chr(33 + (73 * j + 19 * i + 11 * generation) % 94)
                                for j in range(PAYLOAD_BYTES))}
            for i in range(COUNT)]


def logical_hash(generation):
    return digest(canonical(records(generation)))


def make_state(generation, schema=SCHEMA):
    rows = records(generation)
    blob = canonical({"status": "COMMITTED", "generation": generation,
                      "logical_hash": digest(canonical(rows)), "records": rows})
    state = {"schema": schema, "status": "COMPLETED", "generation": generation,
             "logical_hash": digest(canonical(rows)), "records": rows,
             "original_sha256": digest(ORIGINAL),
             "blob": "g%d-%s.blob" % (generation, digest(blob)),
             "blob_sha256": digest(blob)}
    return state, blob


class IO:
    """Contatori applicativi; non fingono di osservare I/O/fsync interni SQLite."""
    def __init__(self, fault="none"):
        self.fault = fault
        self.bytes_written = 0
        self.write_calls = 0
        self.file_fsync = 0
        self.directory_fsync = 0
        self.events = []

    def event(self, operation, role, destination):
        self.events.append({"sequence": len(self.events), "operation": operation,
                            "role": role, "destination": destination})

    def write(self, fd, data):
        view = memoryview(data)
        position = 0
        while position < len(view):
            if self.fault == "enospc" and self.bytes_written >= 4096:
                raise OSError(errno.ENOSPC, "simulated ENOSPC; disk not filled")
            if self.fault == "short-zero" and self.bytes_written:
                n = 0
            else:
                size = 113 if self.fault in ("short", "short-zero", "enospc") else 65536
                n = os.write(fd, view[position:position + size])
            self.write_calls += 1
            if n <= 0:
                raise Stop("SHORT_WRITE", "write returned zero before completion")
            self.bytes_written += n
            position += n

    def sync_file(self, fd, role="artifact", destination="unspecified"):
        if self.fault == "omit-manifest-sync" and role == "manifest":
            return
        if self.fault == "omit-blob-sync" and role == "blob":
            return
        os.fsync(fd)
        self.file_fsync += 1
        self.event("fsync", role, destination)

    def sync_dir(self, path, role="artifact_directory", destination="unspecified"):
        if self.fault == "omit-project-dir-sync" and role == "project_directory":
            return
        if self.fault == "omit-blob-dir-sync" and role == "blob_directory":
            return
        with directory(path) as fd:
            os.fsync(fd)
            self.directory_fsync += 1
            self.event("fsync", role, destination)

    def stats(self):
        return {"application_bytes_written": self.bytes_written,
                "application_write_calls": self.write_calls,
                "application_file_fsync": self.file_fsync,
                "application_directory_fsync": self.directory_fsync,
                "durability_events": list(self.events),
                "sqlite_internal_bytes_and_fsync": "NOT_INSTRUMENTED"}


@functools.lru_cache(maxsize=1)
def committed_blob_name():
    return "blobs/" + make_state(2)[0]["blob"]


def assert_durability(events, backend, committed=True, acknowledged=False):
    """Verifica chiamate completate; non attribuisce fsync Python a SQLite."""
    destination = committed_blob_name()
    expected = [("fsync", "blob", destination)]
    if backend == "json":
        expected.append(("fsync", "manifest", "project.json.next"))
    expected += [("rename", "blob", destination),
                 ("fsync", "blob_directory", "blobs/")]
    if committed:
        expected.append(("commit_full_returned" if backend == "sqlite" else "rename",
                         "project", "project.sqlite" if backend == "sqlite" else "project.json"))
        if backend == "json":
            expected.append(("fsync", "project_directory", "store/"))
    if acknowledged:
        expected.append(("ack", "project_and_blob", "supervisor_pipe"))
    actual = [(e["operation"], e["role"], e["destination"]) for e in events]
    if actual != expected or [e["sequence"] for e in events] != list(range(len(events))):
        raise Stop("DURABILITY_ORDER", "missing, extra or unordered completed durability operation")


@contextlib.contextmanager
def lock(store, exclusive):
    fd = open_regular(store / "writer.lock", os.O_RDONLY)
    try:
        try:
            fcntl.flock(fd, (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH) | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise Stop("CONFLICT", "project lock is held; no automatic retry") from exc
        yield
    finally:
        os.close(fd)


@contextlib.contextmanager
def sqlite_writer(store):
    BACKEND_CALLS["sqlite"] += 1
    inspect_sqlite_files(store)
    with directory(store) as fd:
        with contextlib.closing(sqlite3.connect("/proc/self/fd/%d/project.sqlite" % fd,
                                              timeout=0, isolation_level=None)) as db:
            mode = db.execute("PRAGMA journal_mode=WAL").fetchone()[0]
            db.execute("PRAGMA synchronous=FULL")
            db.execute("PRAGMA wal_autocheckpoint=0")
            require(mode == "wal", "SQLite did not select WAL")
            require(db.execute("PRAGMA synchronous").fetchone()[0] == 2,
                    "SQLite synchronous is not FULL")
            require(db.execute("PRAGMA wal_autocheckpoint").fetchone()[0] == 0,
                    "SQLite wal_autocheckpoint is not zero")
            yield db


def put_sql(db, state):
    meta = {key: value for key, value in state.items() if key != "records"}
    db.execute("DELETE FROM metadata")
    db.execute("INSERT INTO metadata VALUES (?)", (canonical(meta).decode("ascii"),))
    db.execute("DELETE FROM records")
    db.executemany("INSERT INTO records VALUES (?, ?)",
                   [(row["id"], canonical(row).decode("ascii")) for row in state["records"]])
    db.execute("PRAGMA user_version=%d" % state["schema"])


def raw_state(store, backend, scratch):
    """Il chiamante tiene il lock. La copia SQLite evita sidecar sul sorgente."""
    check_scratch(scratch, "none", probe=False)
    BACKEND_CALLS[backend] += 1
    if backend == "json":
        encoded = read_bytes(store / "project.json")
        return strict_json(encoded), {"manifest_application_bytes_read": len(encoded)}
    snapshot = scratch / ("read-" + uuid.uuid4().hex)
    ACCESS_EVENTS.append("snapshot_mkdir")
    mkdir(snapshot)
    copied = 0
    try:
        for name in ("project.sqlite", "project.sqlite-wal"):
            source = store / name
            try:
                source_fd = open_regular(source, os.O_RDONLY)
            except FileNotFoundError:
                continue
            ACCESS_EVENTS.append("snapshot_copy")
            with os.fdopen(source_fd, "rb") as src:
                with os.fdopen(open_regular(snapshot / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL), "wb") as dst:
                    shutil.copyfileobj(src, dst, 65536)
                    copied += src.tell()
        with directory(snapshot) as snapshot_fd, contextlib.ExitStack() as stack:
            uri = "file:/proc/self/fd/%d/project.sqlite?mode=ro" % snapshot_fd
            db = stack.enter_context(contextlib.closing(sqlite3.connect(uri, uri=True, isolation_level=None)))
            version = db.execute("PRAGMA user_version").fetchone()[0]
            if version not in (0, SCHEMA):
                return {"schema": version}, {"snapshot_copy_bytes": copied}
            require(db.execute("PRAGMA integrity_check").fetchall() == [("ok",)],
                    "SQLite integrity_check failed")
            meta_rows = db.execute("SELECT document FROM metadata").fetchall()
            require(len(meta_rows) == 1, "metadata cardinality")
            document = meta_rows[0][0]
            state = strict_json(document if isinstance(document, bytes) else document.encode("utf-8"))
            require(state["schema"] == version, "schema metadata/header mismatch")
            state["records"] = [strict_json(row[0].encode("utf-8")) for row in
                                db.execute("SELECT document FROM records ORDER BY id")]
            return state, {"snapshot_copy_bytes": copied, "journal_mode":
                           db.execute("PRAGMA journal_mode").fetchone()[0],
                           "schema": version}
    finally:
        with directory(scratch) as fd:
            shutil.rmtree(snapshot.name, dir_fd=fd)


def verify(store, state):
    require(state["status"] == "COMPLETED", "committed project is not COMPLETED")
    generation = state["generation"]
    require(type(generation) is int and generation in (1, 2), "invalid generation")
    expected, blob = make_state(generation, state["schema"])
    require(canonical(state) == canonical(expected),
            "committed project differs from exact SYN-STATE oracle")
    path = store / "blobs" / state["blob"]
    require(path.is_file() and not path.is_symlink(), "missing/unsafe committed blob")
    data = read_bytes(path)
    require(digest(data) == state["blob_sha256"], "COMMITTED blob hash mismatch")
    decoded = strict_json(data)
    require(decoded["status"] == "COMMITTED", "referenced blob is not COMMITTED")
    require(data == blob, "COMMITTED blob differs from exact oracle")
    original = store.parent / "original.bin"
    require(file_hash(original) == digest(ORIGINAL), "immutable original changed")
    require(original.stat().st_mode & 0o222 == 0, "original must have no write mode bits")
    return {"verified_blob_application_bytes_read": len(data),
            "original_hash_application_bytes_read": len(ORIGINAL)}


def recover(store, backend, scratch):
    start = time.monotonic_ns()
    check_scratch(scratch, "none")
    with lock(store, False):
        state, settings = raw_state(store, backend, scratch)
        require(type(state["schema"]) is int and state["schema"] >= 0, "invalid schema identifier")
        if state["schema"] != SCHEMA:
            return {"status": "READ_ONLY", "schema": state["schema"],
                    "reason": "schema unsupported; no migration or fallback", **settings}
        verified_io = verify(store, state)
        referenced = state["blob"]
        orphans = sorted(str(p.relative_to(store)) for p in (store / "blobs").iterdir()
                         if p.name != referenced)
        orphans += sorted(p.name for p in store.glob("*.next"))
        return {"status": "COMPLETED", "generation": state["generation"],
                "logical_hash": state["logical_hash"], "published_blob": referenced,
                "orphans": orphans,
                "orphan_policy": "diagnose_only_never_publish_or_delete",
                "reopen_ns": time.monotonic_ns() - start, **settings, **verified_io}


def durable_file(path, data, io, mode=0o600):
    fd = open_regular(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    try:
        io.write(fd, data)
        io.sync_file(fd)
    finally:
        os.close(fd)


def initialize(case, backend, schema=SCHEMA, prepared=False):
    if prepared:
        with directory(case) as fd:
            require(not os.listdir(fd), "initialized case capability must be empty")
    else:
        mkdir(case)
    store, scratch = case / "store", case / "scratch"
    mkdir(store)
    mkdir(scratch)
    mkdir(store / "blobs")
    io = IO()
    durable_file(case / "original.bin", ORIGINAL, io, 0o444)
    durable_file(store / "writer.lock", b"M1.c lock\n", io)
    state, blob = make_state(1, schema)
    durable_file(store / "blobs" / state["blob"], blob, io)
    io.sync_dir(store / "blobs")
    if backend == "json":
        BACKEND_CALLS["json"] += 1
        durable_file(store / "project.json", canonical(state), io)
    else:
        with sqlite_writer(store) as db:
            db.execute("CREATE TABLE metadata (document TEXT NOT NULL)")
            db.execute("CREATE TABLE records (id INTEGER PRIMARY KEY, document TEXT NOT NULL)")
            db.execute("BEGIN IMMEDIATE")
            put_sql(db, state)
            db.execute("COMMIT")
            require(db.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()[0] == 0,
                    "initial checkpoint failed")
    io.sync_dir(store)
    io.sync_dir(scratch)
    io.sync_dir(case)
    if not prepared:
        io.sync_dir(case.parent)
    return {"generation": 1, "logical_hash": state["logical_hash"], **io.stats()}


def check_scratch(scratch, fault, probe=True):
    if fault == "reserve":
        raise Stop("RESERVATION", "simulated available reservation 0 < 4194304")
    try:
        with directory(scratch) as fd:
            if os.fstat(fd).st_mode & 0o222 == 0:
                raise Stop("SCRATCH_UNWRITABLE", "application mode-bit rejection; not an OS permission test")
            if probe:
                name = "probe-" + uuid.uuid4().hex
                probe_fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                                   0o600, dir_fd=fd)
                os.close(probe_fd)
                os.unlink(name, dir_fd=fd)
    except (NotADirectoryError, FileNotFoundError) as exc:
        raise Stop("SCRATCH_NOT_DIRECTORY", "scratch must be an existing non-symlink directory") from exc
    except PermissionError as exc:
        raise Stop("SCRATCH_UNWRITABLE", "scratch access/probe rejected by OS") from exc
    ACCESS_EVENTS.append("scratch_preflight_ok")


def commit(case, backend, gate, fault="none", expected=1):
    store, scratch = case / "store", case / "scratch"
    io = IO(fault)
    start = time.monotonic_ns()
    # Prima anche della copia SQLite e di ogni probe/scrittura del writer.
    check_scratch(scratch, fault)
    with lock(store, True):
        old, settings = raw_state(store, backend, scratch)
        require(type(old["schema"]) is int and old["schema"] >= 0, "invalid schema identifier")
        if old["schema"] != SCHEMA:
            raise Stop("SCHEMA_READ_ONLY", "writing unsupported schema is forbidden")
        verify(store, old)
        if old["generation"] != expected:
            raise Stop("CONFLICT", "expected generation is stale; no lost update")
        require(expected == 1, "fixture supports exactly generations 1 and 2")
        state, blob = make_state(2)
        db = None
        db_context = contextlib.ExitStack()
        blob_fd = manifest_fd = None
        try:
            if backend == "sqlite":
                db = db_context.enter_context(sqlite_writer(store))
                settings.update({"writer_journal_mode": db.execute("PRAGMA journal_mode").fetchone()[0],
                                 "writer_synchronous": db.execute("PRAGMA synchronous").fetchone()[0],
                                 "writer_wal_autocheckpoint": db.execute("PRAGMA wal_autocheckpoint").fetchone()[0]})
                db.execute("BEGIN IMMEDIATE")
                put_sql(db, state)
            else:
                manifest_fd = open_regular(store / "project.json.next",
                                           os.O_WRONLY | os.O_CREAT | os.O_EXCL)
                ACCESS_EVENTS.append("manifest_write")
                io.write(manifest_fd, canonical(state))
            staging = store / "blobs" / (state["blob"] + ".next")
            blob_fd = open_regular(staging, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
            ACCESS_EVENTS.append("blob_write")
            io.write(blob_fd, blob)
            gate("after_write", io.stats())
            io.sync_file(blob_fd, "blob", "blobs/" + state["blob"])
            if manifest_fd is not None:
                io.sync_file(manifest_fd, "manifest", "project.json.next")
            gate("after_file_sync", io.stats())
            os.close(blob_fd)
            blob_fd = None
            replace(staging, store / "blobs" / state["blob"])
            io.event("rename", "blob", "blobs/" + state["blob"])
            io.sync_dir(store / "blobs", "blob_directory", "blobs/")
            if manifest_fd is not None:
                os.close(manifest_fd)
                manifest_fd = None
            assert_durability(io.events, backend, committed=False)
            gate("before_commit", io.stats())
            commit_start = time.monotonic_ns()
            if db is not None:
                db.execute("COMMIT")
                io.event("commit_full_returned", "project", "project.sqlite")
            else:
                BACKEND_CALLS["json"] += 1
                replace(store / "project.json.next", store / "project.json")
                io.event("rename", "project", "project.json")
            primitive_ns = time.monotonic_ns() - commit_start
            gate("after_commit", io.stats())
            if db is None:
                io.sync_dir(store, "project_directory", "store/")
            assert_durability(io.events, backend)
            gate("before_ack", io.stats())
            # ACK riguarda progetto e blob. SQLite FULL gestisce il proprio WAL.
            gate("ack", {"generation": 2, "logical_hash": state["logical_hash"], **io.stats()})
            io.event("ack", "project_and_blob", "supervisor_pipe")
            gate("after_ack", io.stats())
            return {"status": "COMPLETED", "generation": 2,
                    "logical_hash": state["logical_hash"], "settings": settings,
                    "primitive_commit_ns": primitive_ns,
                    "commit_ns": time.monotonic_ns() - commit_start,
                    "total_ns": time.monotonic_ns() - start, **io.stats()}
        except Exception as exc:
            exc.io_stats = io.stats()
            raise
        finally:
            for fd in (blob_fd, manifest_fd):
                if fd is not None:
                    os.close(fd)
            db_context.close()


def migrate(case, backend, fail=False):
    store, scratch = case / "store", case / "scratch"
    io = IO()
    check_scratch(scratch, "none")
    with lock(store, True):
        state, _ = raw_state(store, backend, scratch)
        if state["schema"] != 0:
            raise Stop("SCHEMA_READ_ONLY", "only explicit legacy 0 -> 1 migration exists")
        verify(store, state)
        state["schema"] = SCHEMA
        if backend == "sqlite":
            with sqlite_writer(store) as db:
                db.execute("BEGIN IMMEDIATE")
                put_sql(db, state)
                if fail:
                    raise Stop("MIGRATION_INJECTED", "failure before migration commit")
                db.execute("COMMIT")
        else:
            durable_file(store / "migration.next", canonical(state), io)
            if fail:
                raise Stop("MIGRATION_INJECTED", "failure before migration rename")
            replace(store / "migration.next", store / "project.json")
            io.sync_dir(store)
    return {"status": "MIGRATED", "from_schema": 0, "to_schema": SCHEMA, **io.stats()}
