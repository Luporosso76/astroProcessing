#!/usr/bin/env python3
"""Harness M1.c. Importare questo file non avvia prove."""

import os

# Il protocollo non consulta configurazioni OpenSSL della sessione dell'utente.
os.environ["OPENSSL_CONF"] = "/dev/null"

import argparse
import errno
import json
import math
from pathlib import Path
import random
import resource
import selectors
import signal
import sqlite3
import ssl
import stat
import statistics
import subprocess
import sys
import time

# -I esclude anche la directory dello script. Si abilita solo questa directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import persist


BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
MIB = 1024 * 1024
SCRATCH_LIMIT = 1024 * MIB
SCRATCH_PLANNED = 192 * MIB
RSS_LIMIT = 512 * MIB
GUARD_SECONDS = 60
REPLICAS = 3
PLAN_SHA256 = "1f04fa01a6042ce66c1c1e511de798a92bd6c0b8b7be17ece0ffda0abb20cbba"
CASE_GRANTS = {}
PROTOCOL = {
    "id": "M1.c-isolated-v2", "plan_sha256": PLAN_SHA256, "unit": "c", "records": 256,
    "payload_bytes_per_record": 1024, "generations": [1, 2], "replicas": REPLICAS,
    "points": list(persist.POINTS), "hash": "sha256", "encoding": "UTF-8 strict",
    "json": "sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False",
    "json_rejects": ["duplicate keys", "NaN", "Infinity", "invalid UTF-8"],
    "lock": "Linux flock LOCK_NB; writers exclusive, readers shared; stale generation rejected",
    "sqlite": "WAL, synchronous=FULL (2), wal_autocheckpoint=0, timeout=0",
    "sqlite_reader": "copy main+WAL under shared application lock; open copy mode=ro",
    "blob": "file fsync, rename in blobs/, directory fsync BEFORE project commit",
    "orphans": "diagnose only, never publish, never delete automatically",
    "fallback": "forbidden; selected backend fixed before preflight",
    "crash_signal": "SIGKILL only on subprocess.Popen objects created by this harness",
    "point_mapping": {
        "after_write": "SQL transaction staged / JSON .next written; external blob written, unsynced",
        "after_file_sync": "external blob fsync; JSON also .next fsync; NOT an internal SQLite WAL sync hook",
        "before_commit": "blob renamed and directory synced; immediately before SQL COMMIT / JSON rename",
        "after_commit": "SQL COMMIT returned (FULL) / JSON rename returned, directory not yet synced",
        "before_ack": "SQL FULL commit returned / JSON directory fsync returned; ACK not sent",
        "after_ack": "ACK line received by supervisor; child blocks at after_ack handshake",
    },
    "crash_oracle": "points 1-5: exact generation 1 OR 2; point 6: exact generation 2",
    "power_loss": "NOT_IMPLEMENTED: SIGKILL is process crash, not power loss",
    "buffers_planned_bytes": 16 * MIB, "buffer_limit_bytes": 256 * MIB,
    "scratch_planned_bytes": SCRATCH_PLANNED, "scratch_limit_bytes": SCRATCH_LIMIT,
    "rss_supervisor_limit_bytes": RSS_LIMIT, "rss_guard": "best effort, not anti-OOM guarantee",
    "child_address_space_limit_bytes": 768 * MIB, "child_file_limit_bytes": 32 * MIB,
    "supervisor_guard_seconds_per_child": GUARD_SECONDS,
    "faults": "short positive write=113 bytes, zero-write after first chunk, ENOSPC after >=4096 bytes",
    "reservation_fault": "writer reports zero available reservation, before new blob/project writes",
    "scratch_permissions": "reject absent directory or unset write mode bits; then actual O_EXCL probe",
    "measure": "3 distinct process replicas per candidate; each 2 warmups + 7 rounds; startup separate",
    "ordering": "backend(s) frozen before execution; alternating round-robin inside each p; no fallback",
    "comparison": "exp(median(log(T_sqlite[p,r]/T_json[p,r]))); hierarchical paired bootstrap 2000 seed 4059",
    "series": "new UUID for validate; measure requires same ID, protocol hash, source hashes and candidates",
    "worker_access": "inherited directory fd and pipe manifest from supervisor; private new cases only; not OS sandbox",
}


def emit(event):
    sys.stdout.buffer.write(persist.canonical(event) + b"\n")
    sys.stdout.buffer.flush()


def source_hashes():
    paths = [BASE / "run.py", BASE / "persist.py", BASE / "README.md",
             ROOT / "plans/M1-spikes.md", ROOT / "docs/decisions/M0-policy.md"]
    return {str(path.relative_to(ROOT)): persist.file_hash(path) for path in paths}


def independent_oracle():
    """Stessa formula preregistrata, generatore distinto dal codice del writer."""
    result = {}
    parent = "0" * 64
    for generation in (1, 2):
        rows = []
        for index in range(256):
            value = (19 * index + 11 * generation) % 94
            payload = bytearray()
            for _ in range(1024):
                payload.append(33 + value)
                value = (value + 73) % 94
            rows.append(dict(id=index, recipe="SYN-STATE/g%d" % generation,
                             parent_hash=parent, payload=payload.decode("ascii")))
        parent = persist.digest(persist.canonical(rows))
        result[str(generation)] = parent
    persist.require(result["1"] != result["2"], "generations must be distinguishable")
    return result


def allocated_bytes(path):
    persist.require(not path.is_symlink(), "symlink as scratch root")
    total = path.stat().st_blocks * 512
    for root, directories, files in os.walk(path, followlinks=False):
        for name in directories + files:
            try:
                entry = Path(root) / name
                # Conta il link stesso, senza leggere il bersaglio delle fixture ostili.
                total += entry.lstat().st_blocks * 512
            except FileNotFoundError:
                # Il figlio può rimuovere soltanto la propria copia di lettura.
                continue
    return total


def process_metrics(pid):
    values = {}
    try:
        with open("/proc/%d/status" % pid, encoding="ascii") as stream:
            for line in stream:
                key, _, value = line.partition(":")
                if key in ("VmRSS", "VmHWM"):
                    values[key] = int(value.split()[0]) * 1024
                elif key == "Threads":
                    values[key] = int(value.strip())
    except FileNotFoundError:
        pass
    return values


def process_io():
    result = {}
    with open("/proc/self/io", encoding="ascii") as stream:
        for line in stream:
            key, value = line.split(":")
            result[key] = int(value)
    return result


def snapshot_hashes(store):
    return {str(p.relative_to(store)): persist.file_hash(p)
            for p in sorted(store.rglob("*")) if p.is_file()}


def output_json(path, value):
    io = persist.IO()
    staging = path.with_name(path.name + ".writing")
    persist.durable_file(staging, persist.canonical(value) + b"\n", io)
    persist.replace(staging, path)
    io.sync_dir(path.parent)


class Child:
    def __init__(self, args, output, backend, case, action, *, fault="none", handshake=False,
                 invalid_capability=False, missing_capability=False):
        self.output = output
        self.backend = backend
        self.start_ns = time.monotonic_ns()
        self.start = time.monotonic()
        self.peak_rss = 0
        self.max_threads = 0
        self.events = []
        self.pending = []
        self.buffers = {"stdout": b"", "stderr": b""}
        self.stderr = b""
        self.result = None
        if action in ("init", "init-legacy", "measure"):
            persist.mkdir(case)
            with persist.directory(case) as fd:
                info = os.fstat(fd)
                CASE_GRANTS[str(case)] = (info.st_dev, info.st_ino)
            persist.IO().sync_dir(case.parent)
        persist.require(str(case) in CASE_GRANTS, "case not created by this supervisor")
        with persist.directory(case) as fd:
            self.case_fd = os.dup(fd)
        info = os.fstat(self.case_fd)
        persist.require((info.st_dev, info.st_ino) == CASE_GRANTS[str(case)] and
                        info.st_mode & 0o077 == 0, "case capability identity/privacy changed")
        cap_read, cap_write = os.pipe()
        capability = {"case": str(case), "device": info.st_dev, "inode": info.st_ino,
                      "supervisor": os.getpid(), "action": action, "backend": backend,
                      "fault": fault, "handshake": handshake, "series_id": args.series_id,
                      "protocol_id": PROTOCOL["id"], "protocol_hash": persist.digest(persist.canonical(PROTOCOL))}
        if invalid_capability:
            capability["action"] = "not-authorized"
        os.write(cap_write, persist.canonical(capability) + b"\n")
        os.close(cap_write)
        command = [sys.executable, "-I", "-B", str(BASE / "run.py"),
                    "--worker", action, "--backend", backend, "--case", str(case),
                    "--fault", fault, "--series-id", args.series_id]
        if not missing_capability:
            command += ["--case-fd", str(self.case_fd), "--capability-fd", str(cap_read)]
        if handshake:
            command.append("--handshake")
        env = {"TMPDIR": str(output / "scratch"),
               "XDG_CACHE_HOME": str(output / "cache"),
               "XDG_CONFIG_HOME": str(output / "config"),
               "PYTHONDONTWRITEBYTECODE": "1", "PYTHONNOUSERSITE": "1",
               "OPENSSL_CONF": "/dev/null", "LC_ALL": "C.UTF-8"}
        try:
            self.start_ns = time.monotonic_ns()
            self.start = time.monotonic()
            self.proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE, cwd=BASE, env=env, bufsize=0,
                                         pass_fds=() if missing_capability else (self.case_fd, cap_read))
        finally:
            os.close(cap_read)
            os.close(self.case_fd)
        self.selector = selectors.DefaultSelector()
        for label, stream in (("stdout", self.proc.stdout), ("stderr", self.proc.stderr)):
            os.set_blocking(stream.fileno(), False)
            self.selector.register(stream, selectors.EVENT_READ, label)

    def guard(self):
        metrics = process_metrics(self.proc.pid)
        self.peak_rss = max(self.peak_rss, metrics.get("VmRSS", 0), metrics.get("VmHWM", 0))
        self.max_threads = max(self.max_threads, metrics.get("Threads", 0))
        if self.peak_rss > RSS_LIMIT:
            raise persist.Stop("RSS_GUARD", "own child exceeded 512 MiB observed RSS")
        if time.monotonic() - self.start > GUARD_SECONDS:
            raise persist.Stop("TIME_GUARD", "own child exceeded 60 s guard; not product SLA")
        if allocated_bytes(ROOT / "tmp") > SCRATCH_LIMIT:
            raise persist.Stop("SCRATCH_GUARD", "series exceeded 1 GiB allocated scratch")

    def next_event(self):
        while not self.pending:
            self.guard()
            if not self.selector.get_map():
                return None
            for key, _ in self.selector.select(timeout=0.01):
                data = os.read(key.fd, 65536)
                label = key.data
                if not data:
                    self.selector.unregister(key.fileobj)
                    persist.require(not self.buffers[label], "unterminated worker protocol line")
                    continue
                if label == "stderr":
                    self.stderr += data
                    persist.require(len(self.stderr) <= 65536, "worker stderr exceeded bound")
                    continue
                self.buffers[label] += data
                persist.require(len(self.buffers[label]) <= MIB, "worker protocol exceeded bound")
                while b"\n" in self.buffers[label]:
                    line, self.buffers[label] = self.buffers[label].split(b"\n", 1)
                    event = persist.strict_json(line)
                    if "event" not in event:
                        raise persist.Stop("WORKER_STOP", "worker protocol stopped: " + str(event))
                    self.events.append(event)
                    self.pending.append(event)
        return self.pending.pop(0)

    def release(self):
        self.proc.stdin.write(b"continue\n")
        self.proc.stdin.flush()

    def command(self, value):
        self.proc.stdin.write(persist.canonical(value) + b"\n")
        self.proc.stdin.flush()

    def receive(self, kind):
        event = self.next_event()
        persist.require(event is not None and event["event"] == kind,
                        "worker did not return expected " + kind)
        return event

    def until(self, point):
        while True:
            event = self.next_event()
            persist.require(event is not None, "child exited before requested handshake")
            if event["event"] == "point":
                if event["point"] == point:
                    return event
                self.release()
            elif event["event"] == "result":
                raise persist.Stop("HANDSHAKE", "child returned before requested point")

    def finish(self, expected=0, killed=False):
        try:
            while True:
                event = self.next_event()
                if event is None:
                    break
                if event["event"] == "point":
                    persist.require(not killed, "unexpected queued handshake after SIGKILL")
                    self.release()
                elif event["event"] == "result":
                    persist.require(self.result is None, "duplicate worker result")
                    self.result = event
            code = self.proc.wait(timeout=2)
            persist.require(code == expected, "worker exit %d != expected %d; %s" %
                            (code, expected, self.stderr.decode("utf-8", "replace")))
            if not killed:
                persist.require(self.result is not None, "worker result absent")
                persist.require(self.result["backend"] == self.backend, "backend identity changed")
                other = "json" if self.backend == "sqlite" else "sqlite"
                persist.require(self.result["backend_calls"][other] == 0,
                                "unselected backend was called")
                if expected != 0:
                    value = self.result["value"]
                    persist.require(value["status"] == "STOP" and value["diagnosis"] and
                                    value["published_output"] is None,
                                    "expected failure lacks diagnosis or published an output")
                    persist.require(not any(e["event"] == "ack" for e in self.events),
                                    "expected failure emitted durability ACK")
            return {"exit_code": code, "result": self.result, "events": self.events,
                    "external_process_ns": time.monotonic_ns() - self.start_ns,
                    "supervisor_peak_rss_bytes": self.peak_rss,
                    "supervisor_max_threads": self.max_threads,
                    "stderr": self.stderr.decode("utf-8", "replace")}
        finally:
            self.close()

    def kill(self):
        if self.proc.poll() is None:
            self.proc.kill()

    def close(self):
        self.kill()
        self.proc.wait()
        self.selector.close()
        for stream in (self.proc.stdin, self.proc.stdout, self.proc.stderr):
            stream.close()


def corrupt(case, backend, kind):
    store = case / "store"
    if kind == "truncated":
        path = store / ("project.json" if backend == "json" else "project.sqlite")
        with os.fdopen(persist.open_regular(path, os.O_RDWR), "r+b") as stream:
            stream.truncate(97)
            stream.flush()
            os.fsync(stream.fileno())
        return
    with persist.lock(store, True):
        state, _ = persist.raw_state(store, backend, case / "scratch")
    if kind in ("blob_hash", "blob_status", "missing_blob"):
        path = store / "blobs" / state["blob"]
        if kind == "missing_blob":
            persist.unlink(path)
        elif kind == "blob_hash":
            with os.fdopen(persist.open_regular(path, os.O_RDWR), "r+b") as stream:
                stream.write(b"X")
                stream.flush()
                os.fsync(stream.fileno())
        else:
            value = persist.strict_json(persist.read_bytes(path))
            value["status"] = "PREPARED"
            # Il controllo nlink precede truncate; O_TRUNC non è mai usato.
            with os.fdopen(persist.open_regular(path, os.O_WRONLY), "wb") as stream:
                stream.truncate(0)
                stream.write(persist.canonical(value))
                stream.flush()
                os.fsync(stream.fileno())
        persist.IO().sync_dir(store / "blobs")
        return
    if kind == "project_status":
        state["status"] = "PREPARED"
    elif kind == "record":
        state["records"][17]["payload"] = "x" * 1024
    elif kind == "future":
        state["schema"] = 999
    payload = persist.canonical(state)
    bad = {"duplicate": b'{"schema":1,"schema":1}',
           "nan": b'{"schema":1,"value":NaN}', "utf8": b'\xff'}
    if backend == "json":
        io = persist.IO()
        persist.durable_file(store / "corrupt.next", bad.get(kind, payload), io)
        persist.replace(store / "corrupt.next", store / "project.json")
        io.sync_dir(store)
    else:
        with persist.sqlite_writer(store) as db:
            db.execute("BEGIN IMMEDIATE")
            if kind in bad:
                # L'UTF-8 invalido resta un BLOB, non una conversione con replacement.
                document = bad[kind] if kind == "utf8" else bad[kind].decode("ascii")
                db.execute("UPDATE metadata SET document=?", (document,))
            else:
                persist.put_sql(db, state)
            db.execute("COMMIT")
            db.execute("PRAGMA wal_checkpoint(TRUNCATE)")


def worker(args):
    start = time.monotonic_ns()
    cpu_start = time.process_time_ns()
    before_io = process_io()
    code = 0

    def gate(point, metrics):
        if point == "ack":
            emit({"event": "ack", **metrics})
        elif args.handshake:
            emit({"event": "point", "point": point, "metrics": metrics})
            if sys.stdin.buffer.readline() != b"continue\n":
                raise persist.Stop("HANDSHAKE", "supervisor did not release exact point")

    try:
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_AS, (768 * MIB, 768 * MIB))
        resource.setrlimit(resource.RLIMIT_FSIZE, (32 * MIB, 32 * MIB))
        persist.require(args.backend in ("sqlite", "json"), "worker requires one primary backend")
        persist.require(args.case_fd is not None and args.capability_fd is not None,
                        "direct worker CLI has no supervisor capability")
        info = os.fstat(args.case_fd)
        persist.require(stat.S_ISFIFO(os.fstat(args.capability_fd).st_mode), "capability must arrive on inherited pipe")
        with os.fdopen(args.capability_fd, "rb") as stream:
            encoded = stream.readline(4097)
            persist.require(len(encoded) <= 4096 and encoded.endswith(b"\n"), "invalid capability manifest")
            capability = persist.strict_json(encoded)
        persist.require(capability == {
            "case": args.case, "device": info.st_dev, "inode": info.st_ino,
            "supervisor": os.getppid(), "action": args.worker, "backend": args.backend,
            "fault": args.fault, "handshake": args.handshake, "series_id": args.series_id,
            "protocol_id": PROTOCOL["id"], "protocol_hash": persist.digest(persist.canonical(PROTOCOL))},
            "capability binding mismatch")
        persist.require(stat.S_ISDIR(info.st_mode) and info.st_mode & 0o077 == 0,
                        "worker capability is not a private directory")
        persist.TRUSTED_FDS.add(args.case_fd)
        case = Path("/proc/self/fd/%d" % args.case_fd)
        if args.worker in ("init", "init-legacy"):
            value = persist.initialize(case, args.backend, 0 if args.worker == "init-legacy" else 1,
                                       prepared=True)
        elif args.worker == "write":
            value = persist.commit(case, args.backend, gate, args.fault)
        elif args.worker == "read":
            value = persist.recover(case / "store", args.backend, case / "scratch")
        elif args.worker == "migrate":
            value = persist.migrate(case, args.backend, args.fault == "migration")
        elif args.worker == "corrupt":
            corrupt(case, args.backend, args.fault)
            value = {"status": "FIXTURE_MUTATED", "kind": args.fault}
        elif args.worker == "measure":
            with persist.directory(case) as fd:
                persist.require(not os.listdir(fd), "measurement case must be newly created")
            emit({"event": "ready", "backend": args.backend, "worker_pid": os.getpid(),
                  "startup_worker_ns": time.monotonic_ns() - start})
            for index in range(9):
                instruction = persist.strict_json(sys.stdin.buffer.readline(4096))
                persist.require(instruction == {"index": index, "p": instruction.get("p"),
                                                "r": index - 1 if index >= 2 else None,
                                                "warmup": index < 2} and
                                instruction["p"] in (1, 2, 3), "measurement command/order changed")
                sample_case = case / ("sample-%d" % index)
                load_start = time.monotonic_ns()
                persist.initialize(sample_case, args.backend)
                fixture_load_ns = time.monotonic_ns() - load_start
                before = process_io()
                cpu = time.process_time_ns()
                total = time.monotonic_ns()
                written = persist.commit(sample_case, args.backend, gate)
                opened = persist.recover(sample_case / "store", args.backend, sample_case / "scratch")
                total = time.monotonic_ns() - total
                cpu = time.process_time_ns() - cpu
                after = process_io()
                emit({"event": "sample", "backend": args.backend, **instruction,
                      "case": "commit-and-reopen", "units": "ns", "method": "monotonic_ns",
                      "T_total_ns": total, "cpu_ns": cpu, "fixture_load_ns": fixture_load_ns,
                      "write": written, "read": opened,
                      "actual_bytes": {"application_written": written["application_bytes_written"],
                                       "snapshot_copied": opened.get("snapshot_copy_bytes", 0),
                                       "reopen_manifest_application_read": opened.get("manifest_application_bytes_read", 0),
                                       "reopen_blob_application_read": opened["verified_blob_application_bytes_read"],
                                       "reopen_original_hash_application_read": opened["original_hash_application_bytes_read"],
                                       "case_physically_allocated": allocated_bytes(sample_case),
                                       "python_heap_allocated": "NOT_INSTRUMENTED; payload/budget and RSS reported separately",
                                       "proc_io_delta": {key: after[key] - before[key] for key in before},
                                       "sqlite_internal": "NOT_INSTRUMENTED"},
                      "peak_rss_bytes": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
                      "worker_pid": os.getpid(), "process": process_metrics(os.getpid())})
            persist.require(sys.stdin.buffer.readline() == b"continue\n", "missing measurement shutdown")
            value = {"status": "COMPLETED", "process_recipe": "2 warmups + 7 rounds in same interpreter"}
        else:
            raise persist.Stop("ACTION", "unknown worker action")
    except Exception as exc:
        code = 3 if isinstance(exc, persist.Stop) and exc.code == "CONFLICT" else 2
        value = {"status": "STOP", "diagnosis": str(exc),
                 "error": exc.code if isinstance(exc, persist.Stop) else type(exc).__name__,
                 "errno": exc.errno if isinstance(exc, OSError) else None,
                  "published_output": None, "application_io": getattr(exc, "io_stats", None)}
        value["access_events"] = list(persist.ACCESS_EVENTS)
    usage = resource.getrusage(resource.RUSAGE_SELF)
    after_io = process_io()
    emit({"event": "result", "backend": args.backend, "value": value,
          "worker_pid": os.getpid(),
          "worker_wall_ns": time.monotonic_ns() - start,
          "worker_cpu_ns": time.process_time_ns() - cpu_start,
          "worker_peak_rss_bytes": usage.ru_maxrss * 1024,
          "process_io_delta": {key: after_io[key] - before_io[key] for key in before_io},
          "process": process_metrics(os.getpid()), "fallback_calls": 0,
          "backend_calls": persist.BACKEND_CALLS})
    return code


class Suite:
    def __init__(self, args, output, oracle):
        self.args, self.output, self.oracle = args, output, oracle
        self.rows = []

    def spawn(self, case, action, **kwargs):
        return Child(self.args, self.output, self.args.backend, case, action, **kwargs)

    def invoke(self, case, action, expected=0, **kwargs):
        child = self.spawn(case, action, **kwargs)
        return child.finish(expected)

    def init(self, name, legacy=False):
        case = self.output / "cases" / name
        self.invoke(case, "init-legacy" if legacy else "init")
        self.unchanged(case)
        return case

    def unchanged(self, case):
        persist.require(persist.file_hash(case / "original.bin") == persist.digest(persist.ORIGINAL),
                        "original fixture changed")
        persist.require((case / "original.bin").stat().st_mode & 0o222 == 0,
                        "original fixture writable")

    def recovered(self, case, allowed):
        result = self.invoke(case, "read")
        value = result["result"]["value"]
        persist.require(value["status"] == "COMPLETED", "no complete committed state recovered")
        generation = value["generation"]
        persist.require(generation in allowed, "wrong committed generation recovered")
        persist.require(value["logical_hash"] == self.oracle[str(generation)],
                        "recovery differs from independent exact logical oracle")
        published = value["published_blob"]
        actual_orphans = {"blobs/" + p.name for p in (case / "store" / "blobs").iterdir()
                          if p.name != published}
        actual_orphans.update(p.name for p in (case / "store").glob("*.next"))
        persist.require(set(value["orphans"]) == actual_orphans, "orphan inventory incomplete")
        persist.require("blobs/" + published not in actual_orphans and not published.endswith(".next"),
                        "orphan or partial blob published as completed output")
        self.unchanged(case)
        return result

    def record(self, name, function):
        row = {"case": name, "implemented": True, "execution": "RUNNING"}
        self.rows.append(row)
        try:
            row["details"] = function()
            row["execution"] = "EXECUTED"
            row["outcome"] = "PASS"
        except Exception as exc:
            row.update(execution="EXECUTED", outcome="FAIL", diagnosis=str(exc))
            raise
        finally:
            output_json(self.output / "cases.json", self.rows)

    def baseline(self):
        case = self.init("baseline")
        first = self.recovered(case, {1})
        written = self.invoke(case, "write", handshake=True)
        self.durability(written)
        second = self.recovered(case, {2})
        persist.require(first["result"]["value"]["logical_hash"] !=
                        second["result"]["value"]["logical_hash"], "fixture cannot distinguish commits")
        return {"old": first, "write": written, "new": second}

    def durability(self, result):
        acks = [e for e in result["events"] if e["event"] == "ack"]
        persist.require(len(acks) == 1, "successful commit must send exactly one ACK")
        persist.assert_durability(acks[0]["durability_events"], self.args.backend)
        persist.assert_durability(result["result"]["value"]["durability_events"],
                                 self.args.backend, acknowledged=True)

    def crash(self, point, replica):
        case = self.init("crash-%s-%d" % (point, replica))
        child = self.spawn(case, "write", handshake=True)
        try:
            child.until(point)
            reached = [e for e in child.events if e["event"] == "point"]
            for event in reached:
                if event["point"] == "before_commit":
                    persist.assert_durability(event["metrics"]["durability_events"],
                                             self.args.backend, committed=False)
                elif event["point"] in ("before_ack", "after_ack"):
                    persist.assert_durability(event["metrics"]["durability_events"], self.args.backend,
                                             acknowledged=event["point"] == "after_ack")
            if point == "after_ack":
                persist.require(any(e["event"] == "ack" for e in child.events),
                                "after_ack kill without received ACK")
            else:
                persist.require(not any(e["event"] == "ack" for e in child.events),
                                "ACK appeared before preregistered kill point")
            child.kill()
            killed = child.finish(expected=-signal.SIGKILL, killed=True)
        finally:
            child.close()
        recovered = self.recovered(case, {2} if point == "after_ack" else {1, 2})
        return {"killed": killed, "recovery": recovered}

    def writer_fault(self, fault):
        case = self.init("fault-" + fault)
        if fault == "scratch-readonly":
            persist.chmod_directory(case / "scratch", 0o500)
        elif fault == "scratch-not-directory":
            persist.unlink(case / "scratch", is_dir=True)
            persist.durable_file(case / "scratch", b"not a directory", persist.IO())
        selected_fault = "none" if fault.startswith("scratch-") else fault
        before = snapshot_hashes(case / "store")
        scratch_before = sorted(p.name for p in (case / "scratch").iterdir()) if fault != "scratch-not-directory" else None
        try:
            result = self.invoke(case, "write", fault=selected_fault, expected=2)
            persist.require(result["result"]["value"]["status"] == "STOP", "fault did not STOP")
            value = result["result"]["value"]
            if fault == "enospc":
                persist.require(value["errno"] == errno.ENOSPC, "ENOSPC fixture failed for another reason")
            elif fault == "short-zero":
                persist.require(value["error"] == "SHORT_WRITE", "short-zero fixture failed for another reason")
            elif fault == "reserve":
                persist.require(value["error"] == "RESERVATION", "reservation fixture failed for another reason")
            elif fault.startswith("scratch-"):
                expected = "SCRATCH_UNWRITABLE" if fault == "scratch-readonly" else "SCRATCH_NOT_DIRECTORY"
                persist.require(value["error"] == expected, "scratch failure did not come from preflight")
                persist.require(not value["access_events"] and
                                result["result"]["backend_calls"] == {"sqlite": 0, "json": 0},
                                "scratch preflight touched a backend, snapshot or writer")
            if fault == "reserve" or fault.startswith("scratch-"):
                persist.require(not value["access_events"] and
                                result["result"]["backend_calls"] == {"sqlite": 0, "json": 0},
                                "rejected preflight reached snapshot/backend/writer")
                persist.require(snapshot_hashes(case / "store") == before,
                                "rejected preflight modified store/sidecars")
                if scratch_before is not None:
                    persist.require(sorted(p.name for p in (case / "scratch").iterdir()) == scratch_before,
                                    "rejected preflight wrote scratch")
            persist.require(not any(e["event"] == "ack" for e in result["events"]), "fault sent ACK")
        finally:
            if fault == "scratch-readonly":
                persist.chmod_directory(case / "scratch", 0o700)
            elif fault == "scratch-not-directory":
                persist.unlink(case / "scratch")
                persist.mkdir(case / "scratch")
        recovered = self.recovered(case, {1})
        return {"failure": result, "old_commit_preserved": recovered,
                "permission_test": "application mode-bit simulation, NOT OS EACCES proof" if
                fault == "scratch-readonly" else "not applicable"}

    def short_write(self):
        case = self.init("short-positive")
        written = self.invoke(case, "write", fault="short")
        value = written["result"]["value"]
        persist.require(value["application_write_calls"] > 1, "short write adapter not exercised")
        return {"write": written, "recovery": self.recovered(case, {2})}

    def corruption(self, kind):
        case = self.init("corruption-" + kind)
        # Conserva un blob gen1 integro per provare che non si torna al vecchio commit.
        self.invoke(case, "write")
        # Il mutatore dedicato crea una fixture corrotta; non è un percorso di recovery.
        self.invoke(case, "corrupt", fault=kind)
        failed = self.invoke(case, "read", expected=2)
        value = failed["result"]["value"]
        persist.require(value["status"] == "STOP" and value["published_output"] is None,
                        "corruption published output or recovered older project")
        errors = {"duplicate": "DUPLICATE_KEY", "nan": "NONFINITE_JSON", "utf8": "UnicodeDecodeError",
                  "truncated": "JSONDecodeError" if self.args.backend == "json" else "DatabaseError"}
        persist.require(value["error"] == errors.get(kind, "INVALID_STATE"),
                        "corruption failed for an unrelated reason")
        self.unchanged(case)
        return failed

    def concurrency(self):
        case = self.init("concurrency")
        first = self.spawn(case, "write", handshake=True)
        try:
            first.until("before_commit")
            conflict = self.invoke(case, "write", expected=3)
            reader_conflict = self.invoke(case, "read", expected=3)
            persist.require(conflict["result"]["value"]["error"] == "CONFLICT", "writer lock not enforced")
            persist.require(reader_conflict["result"]["value"]["error"] == "CONFLICT", "reader lock not enforced")
            first.release()
            committed = first.finish()
        finally:
            first.close()
        stale = self.invoke(case, "write", expected=3)
        persist.require(stale["result"]["value"]["error"] == "CONFLICT", "stale generation accepted")
        return {"writer_conflict": conflict, "reader_conflict": reader_conflict,
                "first_writer": committed, "stale_generation": stale,
                "recovery": self.recovered(case, {2})}

    def future_schema(self):
        case = self.init("future-schema")
        self.invoke(case, "corrupt", fault="future")
        before = snapshot_hashes(case / "store")
        read = self.invoke(case, "read")
        value = read["result"]["value"]
        persist.require(value["status"] == "READ_ONLY" and value["schema"] == 999,
                        "future schema did not remain read-only")
        blocked = self.invoke(case, "write", expected=2)
        persist.require(blocked["result"]["value"]["error"] == "SCHEMA_READ_ONLY",
                        "unknown schema writer did not stop")
        after = snapshot_hashes(case / "store")
        persist.require(before == after, "unknown-schema read/write attempt mutated files or sidecars")
        self.unchanged(case)
        return {"read": read, "write_rejected": blocked, "before": before, "after": after}

    def migration(self, fail):
        case = self.init("migration-" + ("fail" if fail else "success"), legacy=True)
        result = self.invoke(case, "migrate", fault="migration" if fail else "none", expected=2 if fail else 0)
        if fail:
            persist.require(result["result"]["value"]["error"] == "MIGRATION_INJECTED",
                            "migration failed for wrong reason")
            old = self.invoke(case, "read")
            persist.require(old["result"]["value"]["schema"] == 0 and
                            old["result"]["value"]["status"] == "READ_ONLY", "failed migration changed schema")
            with persist.lock(case / "store", False):
                state, _ = persist.raw_state(case / "store", self.args.backend, case / "scratch")
                persist.verify(case / "store", state)
            persist.require(state["generation"] == 1 and state["logical_hash"] == self.oracle["1"],
                            "failed migration lost exact legacy state")
            self.unchanged(case)
            return {"migration": result, "legacy_preserved": old}
        return {"migration": result, "recovery": self.recovered(case, {1})}

    def omitted_sync(self, fault):
        case = self.init(fault)
        result = self.invoke(case, "write", fault=fault, expected=2)
        persist.require(result["result"]["value"]["error"] == "DURABILITY_ORDER",
                        "omitted fsync was not detected by ordered trace")
        return {"failure": result, "recovery": self.recovered(case, {1, 2})}

    def unsafe_fixture(self, kind):
        case = self.init("unsafe-" + kind)
        if kind == "capability":
            before = snapshot_hashes(case / "store")
            failed = self.invoke(case, "corrupt", fault="truncated", invalid_capability=True, expected=2)
            persist.require(failed["result"]["value"]["error"] == "INVALID_STATE" and
                            failed["result"]["backend_calls"] == {"sqlite": 0, "json": 0},
                            "bad capability reached a backend")
            persist.require(snapshot_hashes(case / "store") == before, "bad capability changed fixture")
            direct = self.invoke(case, "corrupt", fault="truncated", missing_capability=True, expected=2)
            persist.require(direct["result"]["value"]["error"] == "INVALID_STATE" and
                            direct["result"]["backend_calls"] == {"sqlite": 0, "json": 0} and
                            snapshot_hashes(case / "store") == before,
                            "worker CLI without capability touched existing case")
            return {"invalid_manifest": failed, "direct_worker_cli": direct}
        sentinel = case / "sentinel.bin"
        persist.durable_file(sentinel, b"private sentinel: never truncate or chmod\n", persist.IO())
        before = persist.file_hash(sentinel)
        mode = sentinel.stat().st_mode
        if kind == "scratch-symlink":
            target = case / "scratch"
            persist.unlink(target, is_dir=True)
        else:
            target = case / "store" / ("project.json" if self.args.backend == "json" else "project.sqlite")
            persist.unlink(target)
        with persist.directory(target.parent) as fd:
            if kind == "manifest-hardlink":
                with persist.directory(case) as source:
                    os.link(sentinel.name, target.name, src_dir_fd=source, dst_dir_fd=fd, follow_symlinks=False)
            else:
                os.symlink(str(sentinel), target.name, dir_fd=fd)
        try:
            chmod_rejected = None
            if kind == "scratch-symlink":
                try:
                    persist.chmod_directory(target, 0o500)
                except OSError as exc:
                    persist.require(exc.errno in (errno.ENOTDIR, errno.ELOOP), "chmod failed for unrelated reason")
                    chmod_rejected = exc.errno
                else:
                    raise persist.Stop("UNSAFE_CHMOD", "chmod followed scratch symlink")
            action = "write" if kind == "scratch-symlink" else "corrupt"
            failed = self.invoke(case, action, fault="truncated" if action == "corrupt" else "none", expected=2)
            value = failed["result"]["value"]
            persist.require(value["error"] == ("UNSAFE_FILE" if kind == "manifest-hardlink" else
                                              "SCRATCH_NOT_DIRECTORY" if kind == "scratch-symlink" else "OSError"),
                            "unsafe alias failed for unrelated reason")
            if kind == "manifest-symlink":
                persist.require(value["errno"] == errno.ELOOP, "NOFOLLOW did not reject symlink")
            # Con un hardlink il reader generico rifiuta anche il sentinel: usa fd solo per questa prova.
            with persist.directory(case) as fd:
                raw = os.open(sentinel.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=fd)
                with os.fdopen(raw, "rb") as stream:
                    persist.require(persist.digest(stream.read()) == before and
                                    os.fstat(stream.fileno()).st_mode == mode, "alias mutated sentinel")
            return {"failure": failed, "sentinel_sha256": before,
                    "chmod_alias_rejected_errno": chmod_rejected,
                    "scope": "synthetic alias inside own private case; not OS sandbox proof"}
        finally:
            persist.unlink(target)


def planned_cases(backend=None):
    names = ["baseline"]
    names += ["crash-%s-%d" % (point, rep) for point in persist.POINTS for rep in range(1, REPLICAS + 1)]
    names += ["fault-" + f for f in ("short-zero", "enospc", "reserve", "scratch-readonly", "scratch-not-directory")]
    names += ["short-positive", "concurrency", "future-schema", "migration-success", "migration-fail"]
    names += ["corruption-" + c for c in ("truncated", "project_status", "blob_hash", "blob_status",
                                          "missing_blob", "record", "duplicate", "nan", "utf8")]
    names += ["omit-blob-sync", "omit-blob-dir-sync"]
    if backend == "json":
        names += ["omit-manifest-sync", "omit-project-dir-sync"]
    names += ["unsafe-" + c for c in ("capability", "scratch-symlink", "manifest-symlink", "manifest-hardlink")]
    return names


def validation(suite):
    suite.record("baseline", suite.baseline)
    for point in persist.POINTS:
        for replica in range(1, REPLICAS + 1):
            suite.record("crash-%s-%d" % (point, replica), lambda p=point, r=replica: suite.crash(p, r))
    for fault in ("short-zero", "enospc", "reserve", "scratch-readonly", "scratch-not-directory"):
        suite.record("fault-" + fault, lambda f=fault: suite.writer_fault(f))
    suite.record("short-positive", suite.short_write)
    suite.record("concurrency", suite.concurrency)
    suite.record("future-schema", suite.future_schema)
    suite.record("migration-success", lambda: suite.migration(False))
    suite.record("migration-fail", lambda: suite.migration(True))
    for kind in ("truncated", "project_status", "blob_hash", "blob_status", "missing_blob",
                  "record", "duplicate", "nan", "utf8"):
        suite.record("corruption-" + kind, lambda k=kind: suite.corruption(k))
    faults = ["omit-blob-sync", "omit-blob-dir-sync"]
    if suite.args.backend == "json":
        faults += ["omit-manifest-sync", "omit-project-dir-sync"]
    for fault in faults:
        suite.record(fault, lambda f=fault: suite.omitted_sync(f))
    for kind in ("capability", "scratch-symlink", "manifest-symlink", "manifest-hardlink"):
        suite.record("unsafe-" + kind, lambda k=kind: suite.unsafe_fixture(k))


def summary(values):
    median = statistics.median(values)
    return {"samples": values, "median": median,
            "mad": statistics.median(abs(v - median) for v in values),
            "min": min(values), "max": max(values)}


def paired_comparison(samples, metric):
    tables = {backend: {(s["p"], s["r"]): metric(s) for s in rows if not s["warmup"]}
              for backend, rows in samples.items()}
    expected = {(p, r) for p in range(1, 4) for r in range(1, 8)}
    persist.require(all(set(table) == expected and all(v > 0 for v in table.values())
                        for table in tables.values()), "incomplete/nonpositive paired timing table")
    logs = {(p, r): math.log(tables["sqlite"][p, r] / tables["json"][p, r]) for p, r in expected}
    estimate = math.exp(statistics.median(logs.values()))
    rng = random.Random(4059)
    draws = []
    for _ in range(2000):
        chosen = [rng.randint(1, 3) for _ in range(3)]
        values = [logs[p, rng.randint(1, 7)] for p in chosen for _ in range(7)]
        draws.append(math.exp(statistics.median(values)))
    draws.sort()

    def percentile(q):
        index = (len(draws) - 1) * q
        lo = int(index)
        hi = min(lo + 1, len(draws) - 1)
        return draws[lo] + (draws[hi] - draws[lo]) * (index - lo)

    return {"reference": "sqlite", "candidate": "json", "units": "dimensionless",
            "method": PROTOCOL["comparison"], "ratio": estimate,
            "ci95_percentile_linear": [percentile(0.025), percentile(0.975)],
            "bootstrap_resamples": 2000, "seed": 4059, "process_clusters": 3,
            "limits": "three clusters describe this series only; no cross-system generalization"}


def measurement(suites, report):
    candidates = list(suites)
    samples = {backend: [] for backend in candidates}
    processes = {backend: [] for backend in candidates}
    startup = {backend: [] for backend in candidates}
    schedule = []
    result = {"samples": samples, "startup": startup, "processes": processes, "schedule": schedule,
              "units": "ns unless field says bytes", "limits": PROTOCOL}
    # Anche un'eccezione conserva i campioni già osservati nel report di fallimento.
    report["measurement"] = result
    for p in range(1, 4):
        children = {}
        try:
            for backend in candidates:
                suite = suites[backend]
                case = suite.output / "cases" / ("process-%d" % p)
                child = suite.spawn(case, "measure")
                children[backend] = child
                processes[backend].append({"p": p, "worker_pid": child.proc.pid, "events": child.events,
                                           "execution": "RUNNING"})
                ready = child.receive("ready")
                startup[backend].append({"p": p, "units": "ns", **ready,
                                         "spawn_to_ready_ns": time.monotonic_ns() - child.start_ns,
                                         "method": "Popen-before timestamp to readiness receipt; caches not flushed"})
            for index in range(9):
                order = candidates if (p + index) % 2 else list(reversed(candidates))
                for backend in order:
                    child = children[backend]
                    child.command({"index": index, "p": p, "r": index - 1 if index >= 2 else None,
                                   "warmup": index < 2})
                    ack = child.receive("ack")
                    sample = child.receive("sample")
                    persist.assert_durability(ack["durability_events"], backend)
                    sample["ack"] = ack
                    persist.require(sample["p"] == p and sample["index"] == index and
                                    sample["backend"] == backend and sample["worker_pid"] == child.proc.pid and
                                    sample["read"]["generation"] == 2 and
                                    sample["read"]["logical_hash"] == suites[backend].oracle["2"],
                                    "sample identity or exact oracle changed")
                    persist.assert_durability(sample["write"]["durability_events"], backend, acknowledged=True)
                    suites[backend].unchanged(suites[backend].output / "cases" /
                                              ("process-%d" % p) / ("sample-%d" % index))
                    samples[backend].append(sample)
                    schedule.append({"p": p, "index": index, "backend": backend})
            for backend, child in children.items():
                child.release()
                processes[backend][-1].update(**child.finish(), execution="EXECUTED")
        finally:
            for backend, child in children.items():
                processes[backend][-1].update(supervisor_peak_rss_bytes=child.peak_rss,
                                              supervisor_max_threads=child.max_threads)
                child.close()
    result.update({"summary": {backend: {"T_total_ns": summary([s["T_total_ns"] for s in rows if not s["warmup"]]),
                                      "commit_ns": summary([s["write"]["commit_ns"] for s in rows if not s["warmup"]]),
                                      "reopen_ns": summary([s["read"]["reopen_ns"] for s in rows if not s["warmup"]])}
                          for backend, rows in samples.items()},
                   "cache": "OS/storage caches not flushed; cold means fresh process only"})
    if candidates == ["sqlite", "json"]:
        result["paired_comparison"] = {
            "T_total_ns": paired_comparison(samples, lambda s: s["T_total_ns"]),
            "commit_ns": paired_comparison(samples, lambda s: s["write"]["commit_ns"]),
            "reopen_ns": paired_comparison(samples, lambda s: s["read"]["reopen_ns"])}
    else:
        result["paired_comparison"] = "NOT_RUN: single primary candidate; no comparison possible"
    return result


def capacity_preflight():
    stat = os.statvfs(BASE)
    available = stat.f_bavail * stat.f_frsize
    persist.require(available >= SCRATCH_PLANNED, "NOT RUN: less than 192 MiB free before fixed-size series")
    persist.require(allocated_bytes(ROOT / "tmp") + SCRATCH_PLANNED <= SCRATCH_LIMIT,
                    "NOT RUN: workspace tmp plus planned series exceeds 1 GiB")
    return {"available_bytes": available, "filesystem_device": BASE.stat().st_dev,
            "filesystem_id": stat.f_fsid, "fragment_bytes": stat.f_frsize,
            "same_filesystem_staging": True,
             "filesystem_power_loss_guarantees": "NOT_VALIDATED"}


def preflight(output):
    capacity = capacity_preflight()
    with persist.directory(output) as fd:
        persist.require(os.fstat(fd).st_mode & 0o077 == 0, "output directory must be private")
    for name in ("scratch", "cache", "config", "cases"):
        persist.mkdir(output / name)
    persist.IO().sync_dir(output)
    return capacity


def supervisor(args):
    output = Path(args.output).absolute()
    persist.require(output.parent == BASE and ".." not in output.parts,
                    "output must be a direct, non-symlink child of tmp/m1-persistence")
    persist.require(args.series_id is not None and 1 <= len(args.series_id) <= 80 and
                    all(c.isascii() and (c.isalnum() or c in "-_") for c in args.series_id),
                    "explicit --series-id requires 1..80 ASCII letters/digits/-/_")
    candidates = ["sqlite", "json"] if args.backend == "both" else [args.backend]
    hashes = source_hashes()
    persist.require(hashes["plans/M1-spikes.md"] == PLAN_SHA256,
                    "protocol plan hash changed; preregister a new protocol before execution")
    oracle = independent_oracle()
    protocol_hash = persist.digest(persist.canonical(PROTOCOL))
    recipe = {"protocol": PROTOCOL, "protocol_hash": protocol_hash, "candidates": candidates,
              "source_hashes": hashes, "oracle": oracle}
    recipe_hash = persist.digest(persist.canonical(recipe))
    # Nessun artefatto o caso viene creato prima del controllo di capacità.
    capacity_preflight()
    if args.phase == "measure":
        prior = persist.strict_json(persist.read_bytes(output / "recovery.json"))
        previous_manifest = persist.strict_json(persist.read_bytes(output / "manifest.json"))
        persist.require(prior["outcome"] == "PASS" and prior["recipe_hash"] == recipe_hash and
                        prior.get("series_id") == args.series_id and
                        prior.get("protocol_hash") == protocol_hash and
                        previous_manifest.get("status") == "PASS" and
                        previous_manifest.get("series_id") == args.series_id and
                        previous_manifest.get("protocol_hash") == protocol_hash and
                        previous_manifest.get("candidates") == candidates and
                        previous_manifest.get("protocol") == PROTOCOL and
                        previous_manifest.get("source_hashes") == hashes and
                        previous_manifest.get("recipe_hash") == recipe_hash,
                        "measure requires matching validated series ID, candidates, sources and protocol; no rerun")
        required = {(backend, name) for backend in candidates for name in planned_cases(backend)}
        persist.require(len(prior.get("cases", [])) == len(required) and
                        {(row["backend"], row["case"]) for row in prior["cases"]} == required and
                        all(row.get("execution") == "EXECUTED" and row.get("outcome") == "PASS"
                            for row in prior["cases"]), "measure requires every original and regression case PASS")
        work = output / "measure"
        persist.mkdir(work)
    else:
        persist.mkdir(output)
        work = output
    manifest = {"status": "PREPARING", "phase": args.phase, "recipe_hash": recipe_hash,
                "series_id": args.series_id, "series_class": "protocol-v2-only; legacy series never relabelled",
                **recipe, "command": [sys.executable, "-I", "-B", "tmp/m1-persistence/run.py",
                                      "--unit", "c", "--phase", args.phase, "--backend", args.backend,
                                      "--series-id", args.series_id, "--output", str(output.relative_to(ROOT))],
                "runtime": {"python": sys.version, "sqlite": sqlite3.sqlite_version,
                            "platform": sys.platform, "machine": os.uname().machine,
                            "sha256_provider_module": type(persist.hashlib.sha256()).__module__,
                            "openssl_reported_by_ssl": ssl.OPENSSL_VERSION,
                            "hash_provider_link_identity": "not independently audited against ssl module",
                            "agent_model_declared": "openai/gpt-6.1-sol"},
                "components": [{"name": "Python standard library", "version": sys.version.split()[0],
                                "origin": "local runtime; no installation or download", "terms": "PSF License"},
                               {"name": "SQLite", "version": sqlite3.sqlite_version,
                                "origin": "local Python sqlite3 linked runtime", "terms": "public domain upstream; build provenance not audited"},
                               {"name": "OpenSSL reported by Python ssl", "version": ssl.OPENSSL_VERSION,
                                "origin": "local runtime; hash-provider link identity not independently audited",
                                "terms": "Apache-2.0" if ssl.OPENSSL_VERSION.startswith("OpenSSL 3.") else "UNVERIFIED"}],
                "tests": [{"case": name, "backend": backend, "implemented": True, "execution": "NOT_RUN"}
                          for backend in candidates for name in planned_cases(backend)],
                "not_run": [{"case": "power-loss", "implemented": False,
                             "reason": "SIGKILL cannot establish power-loss behavior"}],
                "limits": ["one synthetic schema, one local filesystem, Linux flock",
                           "SQLite internal write/fsync counts not instrumented",
                           "SQLite read timing includes main/WAL snapshot copy and integrity_check",
                            "legacy 0 -> 1 is a synthetic migration, not a product schema contract",
                            "three process clusters only; private-directory controls are not an OS sandbox"]}
    suites = {}
    code = 0
    started = False
    report = {"phase": args.phase, "recipe_hash": recipe_hash, "series_id": args.series_id,
              "protocol_hash": protocol_hash, "outcome": "NOT_RUN"}
    output_json(work / "manifest.json", manifest)
    try:
        manifest["preflight"] = preflight(work)
        for backend in candidates:
            backend_work = work / backend
            persist.mkdir(backend_work)
            manifest["preflight"][backend] = preflight(backend_work)
            selected = argparse.Namespace(**vars(args))
            selected.backend = backend
            suites[backend] = Suite(selected, backend_work, oracle)
        started = True
        manifest["status"] = "RUNNING"
        output_json(work / "manifest.json", manifest)
        if args.phase == "validate":
            for backend, suite in suites.items():
                validation(suite)
                persist.require(len(suite.rows) == len(planned_cases(backend)), "missing validation cases")
        else:
            measurement(suites, report)
        persist.require(source_hashes() == hashes, "sources changed during series; series invalid")
        report["outcome"] = "PASS"
    except Exception as exc:
        report.update(outcome="FAIL" if started else "NOT_RUN",
                      diagnosis=str(exc), error=type(exc).__name__)
        code = 2
    finally:
        rows = [{"backend": backend, **row} for backend, suite in suites.items() for row in suite.rows]
        by_name = {(row["backend"], row["case"]): row for row in rows}
        if args.phase == "validate":
            manifest["tests"] = [by_name.get((row["backend"], row["case"]), row) for row in manifest["tests"]]
        manifest["status"] = report["outcome"]
        report["cases"] = rows
        report["allocated_series_bytes"] = allocated_bytes(output)
        report["allocated_workspace_tmp_bytes"] = allocated_bytes(ROOT / "tmp")
        report["power_loss"] = "NOT_RUN"
        output_json(work / "manifest.json", manifest)
        output_json(work / "cases.json", rows)
        output_json(work / ("recovery.json" if args.phase == "validate" else "samples.json"), report)
        with os.fdopen(persist.open_regular(work / "cases.jsonl", os.O_WRONLY | os.O_CREAT | os.O_EXCL), "wb") as stream:
            for row in rows:
                stream.write(persist.canonical(row) + b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        persist.IO().sync_dir(work)
        names = ("manifest.json", "cases.json", "cases.jsonl",
                 "recovery.json" if args.phase == "validate" else "samples.json")
        output_json(work / "artifacts.json", {
            "algorithm": "sha256",
            "files": {name: persist.file_hash(work / name) for name in names if (work / name).exists()},
        })
    emit({"status": report["outcome"], "report": str(work.relative_to(ROOT)),
          "recipe_hash": recipe_hash, "phase": args.phase, "backend": args.backend})
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--unit", choices=["c"], default="c")
    parser.add_argument("--phase", choices=["validate", "measure"], default="validate")
    parser.add_argument("--backend", choices=["sqlite", "json", "both"], required=True)
    parser.add_argument("--series-id")
    parser.add_argument("--output")
    parser.add_argument("--worker", choices=["init", "init-legacy", "write", "read", "migrate", "corrupt", "measure"],
                        help=argparse.SUPPRESS)
    parser.add_argument("--case", help=argparse.SUPPRESS)
    parser.add_argument("--case-fd", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--capability-fd", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--fault", default="none", help=argparse.SUPPRESS)
    parser.add_argument("--handshake", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        persist.require(args.case is not None, "worker requires --case")
        return worker(args)
    if args.output is None:
        parser.error("--output is required")
    return supervisor(args)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as error:
        emit({"status": "STOP", "diagnosis": str(error), "error": type(error).__name__})
        sys.exit(2)
