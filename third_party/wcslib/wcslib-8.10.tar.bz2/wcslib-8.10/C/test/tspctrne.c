/*============================================================================
  WCSLIB 8.10 - an implementation of the FITS WCS standard.
  Copyright (C) 1995-2026, Mark Calabretta

  This file is part of WCSLIB.

  WCSLIB is free software: you can redistribute it and/or modify it under the
  terms of the GNU Lesser General Public License as published by the Free
  Software Foundation, either version 3 of the License, or (at your option)
  any later version.

  WCSLIB is distributed in the hope that it will be useful, but WITHOUT ANY
  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public License for
  more details.

  You should have received a copy of the GNU Lesser General Public License
  along with WCSLIB.  If not, see http://www.gnu.org/licenses.

  Author: Mark Calabretta, Australia Telescope National Facility, CSIRO.
  http://www.atnf.csiro.au/computing/software/wcs
  $Id: tspctrne.c,v 8.10 2026/09/27 05:44:34 mcalabre Exp $
*=============================================================================
*
* tspctrne does a quick test of spctrne().  Not part of the official test
* suite.
*
*---------------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>

#include <spc.h>
#include <wcserr.h>

int main()

{
  wcserr_enable(1);

  const char ctypeS1[] = "VOPT-F2W";
  const double crvalS1 = 1e6;
  const double cdeltS1 = 1e3;
  const double restfrq = 0.0;
  const double restwav = 0.0;

  char   ctypeS2[9];
  double cdeltS2, crvalS2;
  struct wcserr *err;

  strncpy(ctypeS2, "VRAD-???", 9);
  if (spctrne(ctypeS1, crvalS1, cdeltS1, restfrq, restwav,
              ctypeS2, &crvalS2, &cdeltS2, &err)) {
    wcserr_prt(err, 0x0);
    return err->status;
  }

  printf("'%8s'  %12.6e  %12.6e\n'%8s'  %12.6e  %12.6e\n",
    ctypeS1, crvalS1, cdeltS1, ctypeS2, crvalS2, cdeltS2);

  return 0;
}
